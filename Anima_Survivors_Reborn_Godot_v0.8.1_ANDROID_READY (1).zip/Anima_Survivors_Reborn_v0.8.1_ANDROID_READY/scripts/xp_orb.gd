class_name AnimaXPOrb
extends Area3D

var value := 1
var target: Node3D
var attracted := false
var speed := 2.0

func setup(v: int = 1) -> void:
    value = v
    collision_layer = 0
    collision_mask = 2
    var cs := CollisionShape3D.new(); var ss := SphereShape3D.new(); ss.radius = 0.35; cs.shape = ss; add_child(cs)
    var m := SphereMesh.new(); m.radius = 0.18; m.height = 0.34; m.radial_segments = 8; m.rings = 4
    var visual := AnimaFX.primitive(m, Color(0.25,0.95,1.0), 3.5); add_child(visual); visual.scale = Vector3(0.75,1.25,0.75)
    body_entered.connect(_on_body)

func _physics_process(delta: float) -> void:
    rotate_y(delta * 2.8)
    if target and is_instance_valid(target):
        var d := global_position.distance_to(target.global_position)
        if d < 7.5 or attracted:
            attracted = true
            speed = min(18.0, speed + delta * 18.0)
            global_position = global_position.move_toward(target.global_position + Vector3.UP * 0.6, speed * delta)

func _on_body(body: Node3D) -> void:
    if body.has_method("gain_xp"):
        body.gain_xp(value)
        AnimaAudio.play_sfx("pickup",.18,.97,1.08)
        queue_free()
