class_name AnimaWorldBuilder
extends RefCounted

static func _set_if_exists(obj: Object, prop_name: StringName, value: Variant) -> void:
    for info in obj.get_property_list():
        if StringName(info.get("name","")) == prop_name:
            obj.set(prop_name,value)
            return


static func _instantiate_generated(root:Node3D,path:String,pos:Vector3,scale_mul:float=1.0,rot_y:float=0.0)->Node3D:
    if not ResourceLoader.exists(path): return null
    var res=load(path)
    if res==null or not (res is PackedScene): return null
    var inst=res.instantiate()
    if not (inst is Node3D): inst.queue_free(); return null
    var node:=inst as Node3D; root.add_child(node); node.position=pos; node.scale=Vector3.ONE*scale_mul; node.rotation.y=rot_y
    return node

static func _build_generated_setpieces(root:Node3D,p:Dictionary,map_id:String)->void:
    var oni:=_instantiate_generated(root,"res://assets/generated/oni_mask_altar.glb",Vector3(0,2.35,-20.75),.60,PI)
    if oni:
        var light:=OmniLight3D.new(); light.light_color=Color(1.0,.16,.05); light.light_energy=1.65; light.omni_range=5.8; oni.add_child(light); light.position=Vector3(0,1.15,-.7)
    for item in [[Vector3(-9,0,-10),1.15,.35],[Vector3(10,0,-7),.95,-.8],[Vector3(-14,0,7),1.35,1.2],[Vector3(15,0,12),1.05,-1.5]]:
        _instantiate_generated(root,"res://assets/generated/moss_rock_cluster.glb",item[0],item[1],item[2])

static var palettes := {
    "grove":{"ground":Color("416c36"),"ground2":Color("294b2d"),"accent":Color("f28fb8"),"sky":Color("8dc8a4")},
    "desert":{"ground":Color("8c4d32"),"ground2":Color("4b2e2b"),"accent":Color("ff9a5f"),"sky":Color("d59a6a")},
    "shrine":{"ground":Color("657f85"),"ground2":Color("344f5a"),"accent":Color("d4f5ff"),"sky":Color("9fc8d0")},
    "moon":{"ground":Color("294544"),"ground2":Color("192d35"),"accent":Color("a99cff"),"sky":Color("657786")}
}

static func build(root: Node3D, map_id: String) -> Dictionary:
    var p=palettes.get(map_id,palettes.grove)
    var env_node:=WorldEnvironment.new(); root.add_child(env_node)
    var env:=Environment.new()
    var sky:=Sky.new(); var sky_mat:=ProceduralSkyMaterial.new()
    sky_mat.sky_top_color=p.sky.darkened(.42 if map_id!="desert" else .22)
    sky_mat.sky_horizon_color=p.sky.lightened(.18)
    sky_mat.ground_horizon_color=p.ground.lightened(.08)
    sky_mat.ground_bottom_color=p.ground2.darkened(.45)
    sky.sky_material=sky_mat
    env.background_mode=Environment.BG_SKY; env.sky=sky; env.background_energy_multiplier=.72
    env.ambient_light_source=Environment.AMBIENT_SOURCE_SKY; env.ambient_light_color=Color(.58,.67,.78); env.ambient_light_energy=.82
    env.tonemap_mode=Environment.TONE_MAPPER_FILMIC
    env.glow_enabled=true; env.glow_intensity=0.72; env.glow_strength=.92
    env.ssao_enabled=true; env.ssao_radius=2.7; env.ssao_intensity=1.48
    env.fog_enabled=true; env.fog_light_color=p.sky.lightened(.07); env.fog_density=.010 if map_id=="moon" else .0065; env.fog_sky_affect=.78
    _set_if_exists(env,"fog_height",1.2)
    _set_if_exists(env,"fog_height_density",.18 if map_id=="moon" else .08)
    _set_if_exists(env,"volumetric_fog_enabled",OS.get_name()!="Android")
    _set_if_exists(env,"volumetric_fog_density",.018 if map_id=="moon" else .010)
    _set_if_exists(env,"volumetric_fog_length",42.0)
    _set_if_exists(env,"ssr_enabled",OS.get_name()!="Android")
    env_node.environment=env
    var sun:=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-52,-28,0); sun.light_color=Color(1,.89,.74) if map_id!="moon" else Color(.68,.74,1.0); sun.light_energy=1.38 if map_id!="moon" else .92; sun.shadow_enabled=true; root.add_child(sun)
    _set_if_exists(sun,"directional_shadow_max_distance",58.0)
    _set_if_exists(sun,"light_angular_distance",.45)
    var fill:=DirectionalLight3D.new(); fill.rotation_degrees=Vector3(-35,145,0); fill.light_color=p.accent; fill.light_energy=.18; root.add_child(fill)
    # Ground
    var ground_body:=StaticBody3D.new(); root.add_child(ground_body)
    var terrain_mesh:=AnimaEnvironmentMeshes.terrain(hash(map_id)+441,80.0,56,.30 if map_id!="moon" else .18)
    var ground_shader:=load("res://shaders/ground.gdshader")
    var gm:=ShaderMaterial.new(); gm.shader=ground_shader
    gm.set_shader_parameter("base_color",p.ground)
    gm.set_shader_parameter("detail_color",p.ground2)
    gm.set_shader_parameter("accent_color",p.accent)
    gm.set_shader_parameter("wetness",.82 if map_id=="moon" else (.34 if map_id=="shrine" else (.06 if map_id=="grove" else 0.0)))
    gm.set_shader_parameter("relief",.56 if map_id in ["grove","desert"] else .38)
    gm.set_shader_parameter("detail_albedo",load("res://assets/textures/%s_albedo.png" % map_id))
    gm.set_shader_parameter("detail_normal",load("res://assets/textures/%s_normal.png" % map_id))
    gm.set_shader_parameter("detail_roughness",load("res://assets/textures/%s_roughness.png" % map_id))
    var ground:=MeshInstance3D.new(); ground.mesh=terrain_mesh; ground.material_override=gm; ground_body.add_child(ground)
    var gcs:=CollisionShape3D.new(); var box:=BoxShape3D.new(); box.size=Vector3(80,.2,80); gcs.shape=box; gcs.position.y=-.12; ground_body.add_child(gcs)
    # Path
    for axis in [0,1]:
        var path:=BoxMesh.new(); path.size=Vector3(4.6,.025,50) if axis==0 else Vector3(50,.025,4.6)
        var mi:=AnimaFX.primitive(path,p.ground.lightened(.16),0,.88,.0); root.add_child(mi); mi.position.y=.02
    _build_shrine(root,p,map_id)
    _build_generated_setpieces(root,p,map_id)
    _build_ruins(root,p,map_id)
    _build_water(root,p,map_id)
    _scatter(root,p,map_id)
    _ground_details(root,p,map_id)
    _build_atmosphere(root,p,map_id)
    _build_weather(root,p,map_id)
    _build_grass(root,p,map_id)
    return p

static func _build_shrine(root:Node3D,p:Dictionary,map_id:String)->void:
    var shrine:=Node3D.new(); shrine.position=Vector3(0,0,-21); root.add_child(shrine)
    var base:=BoxMesh.new(); base.size=Vector3(7,.5,4.5); var b=AnimaFX.primitive(base,p.ground2,0,.84,.02); shrine.add_child(b); b.position.y=.25
    for level in range(3):
        var roof:=AnimaEnvironmentMeshes.roof(6.8-level*.75,3.8-level*.48,.42); var r:=MeshInstance3D.new(); r.mesh=roof; r.material_override=AnimaFX.mat(Color(.12,.08,.1),0,.54,.12); shrine.add_child(r); r.position.y=1.35+level*1.05
        var core:=BoxMesh.new(); core.size=Vector3(3.6-level*.35,.85,2.4-level*.28); var c=AnimaFX.primitive(core,Color(.42,.14,.12) if map_id!="shrine" else Color(.28,.34,.35),0,.76,.02); shrine.add_child(c); c.position.y=.86+level*1.05
    var glow:=OmniLight3D.new(); glow.light_color=p.accent; glow.light_energy=2; glow.omni_range=8; shrine.add_child(glow); glow.position=Vector3(0,2,2)
    # Premium generated torii; procedural geometry remains the compatibility fallback.
    var premium:=_instantiate_generated(root,"res://assets/generated/torii_premium.glb",Vector3(0,0,-14),1.0,0.0)
    if premium==null:
        var torii:=Node3D.new(); torii.position=Vector3(0,0,-14); root.add_child(torii)
        for x in [-2.2,2.2]:
            var post:=CylinderMesh.new(); post.top_radius=.18; post.bottom_radius=.23; post.height=4.1; var m=AnimaFX.primitive(post,Color(.64,.12,.10),0,.68,.02); torii.add_child(m); m.position=Vector3(x,2.05,0)
        for y in [3.5,4.05]:
            var bar:=BoxMesh.new(); bar.size=Vector3(5.6,.27,.28); var m=AnimaFX.primitive(bar,Color(.72,.13,.11),0,.62,.02); torii.add_child(m); m.position.y=y

static func _build_water(root:Node3D,p:Dictionary,map_id:String)->void:
    var water_shader:=load("res://shaders/water.gdshader")
    var sm:=ShaderMaterial.new(); sm.shader=water_shader
    if map_id=="moon":
        sm.set_shader_parameter("shallow_color",Color(.25,.42,.55,.78))
        sm.set_shader_parameter("deep_color",Color(.04,.09,.18,.94))
    var plane:=PlaneMesh.new(); plane.size=Vector2(15,8); plane.subdivide_width=32; plane.subdivide_depth=20
    var water:=MeshInstance3D.new(); water.mesh=plane; water.material_override=sm; root.add_child(water); water.position=Vector3(-17,.03,15)
    # bridge
    for i in range(8):
        var plank:=BoxMesh.new(); plank.size=Vector3(1.65,.12,.62); var n=AnimaFX.primitive(plank,Color(.25,.14,.08),0,.90,.0); root.add_child(n); n.position=Vector3(-10.6-i*.67,.34,15+sin(i*.7)*.08)

static func _scatter(root:Node3D,p:Dictionary,map_id:String)->void:
    var rng:=RandomNumberGenerator.new(); rng.seed=hash(map_id)+9917
    for i in range(56):
        var x=rng.randf_range(-36,36); var z=rng.randf_range(-36,36)
        if abs(x)<5 or abs(z)<5 or Vector2(x,z).distance_to(Vector2(0,-18))<9:
            continue
        if i%3==0:
            _tree(root,Vector3(x,0,z),p,map_id,rng.randf_range(.8,1.5))
        elif i%3==1:
            _rock(root,Vector3(x,0,z),p,rng.randf_range(.5,1.45))
        else:
            _lantern(root,Vector3(x,0,z),p)

static func _tree(root:Node3D,pos:Vector3,p:Dictionary,map_id:String,s:float)->void:
    var n:=Node3D.new(); n.position=pos; n.scale=Vector3.ONE*s; root.add_child(n)
    var trunk:=MeshInstance3D.new(); trunk.mesh=AnimaEnvironmentMeshes.tree_trunk(hash(pos)+hash(map_id),2.8); trunk.material_override=AnimaFX.mat(Color(.22,.12,.075),0,.92,.0); n.add_child(trunk)
    var color=p.accent if map_id in ["grove","moon"] else (Color(.72,.77,.78) if map_id=="shrine" else Color(.36,.24,.16))
    for j in range(4):
        var c:=MeshInstance3D.new(); c.mesh=AnimaEnvironmentMeshes.canopy(hash(pos)+j*97,.72+float(j%2)*.18)
        var fm:=ShaderMaterial.new(); fm.shader=load("res://shaders/foliage.gdshader"); fm.set_shader_parameter("base_color",color); fm.set_shader_parameter("wind_strength",.045+.022*s)
        c.material_override=fm; n.add_child(c); c.position=Vector3((j%2-.5)*.72,2.35+float(j%3)*.26,(j%3-1)*.30); c.scale=Vector3(1.15,.72,1.05)

static func _rock(root:Node3D,pos:Vector3,p:Dictionary,s:float)->void:
    var n:=MeshInstance3D.new(); n.mesh=AnimaEnvironmentMeshes.rock(hash(pos),.62); n.material_override=AnimaFX.mat(p.ground2.lightened(.08),0,.96,.03); root.add_child(n); n.position=pos+Vector3.UP*.31*s; n.scale=Vector3(s*1.25,s*.72,s)

static func _lantern(root:Node3D,pos:Vector3,p:Dictionary)->void:
    var premium:=_instantiate_generated(root,"res://assets/generated/stone_lantern_premium.glb",pos,.52,0.0)
    if premium:
        var glow:=OmniLight3D.new(); glow.light_color=p.accent; glow.light_energy=.78; glow.omni_range=2.6; premium.add_child(glow); glow.position=Vector3(0,1.05,0); return
    var n:=Node3D.new(); n.position=pos; root.add_child(n)
    var post:=CylinderMesh.new(); post.top_radius=.05; post.bottom_radius=.07; post.height=1.2; var m=AnimaFX.primitive(post,Color(.18,.16,.14),0); n.add_child(m); m.position.y=.6
    var lamp:=BoxMesh.new(); lamp.size=Vector3(.28,.34,.28); var l=AnimaFX.primitive(lamp,p.accent,2.2); n.add_child(l); l.position.y=1.25
    var light:=OmniLight3D.new(); light.light_color=p.accent; light.light_energy=.9; light.omni_range=2.8; n.add_child(light); light.position.y=1.25


static func _build_ruins(root:Node3D,p:Dictionary,map_id:String)->void:
    var rng:=RandomNumberGenerator.new(); rng.seed=hash(map_id)+2601
    for i in range(9):
        var a:=TAU*float(i)/9.0+rng.randf_range(-.16,.16); var d:=rng.randf_range(24.0,32.0)
        var ruin:=Node3D.new(); root.add_child(ruin); ruin.position=Vector3(cos(a)*d,0,sin(a)*d); ruin.rotation.y=-a+rng.randf_range(-.4,.4)
        var stone_mat:=AnimaFX.mat(p.ground2.lightened(.13),0,.91,.04)
        for sx in [-1.0,1.0]:
            var pillar:=MeshInstance3D.new(); pillar.mesh=AnimaEnvironmentMeshes.rock(700+i*31+int(sx*7),.52); pillar.material_override=stone_mat; ruin.add_child(pillar); pillar.position=Vector3(sx*1.15,1.15,0); pillar.scale=Vector3(.65,2.25,.65)
        if i%2==0:
            var arch:=MeshInstance3D.new(); arch.mesh=AnimaEnvironmentMeshes.rock(900+i,.62); arch.material_override=stone_mat; ruin.add_child(arch); arch.position=Vector3(0,2.35,0); arch.scale=Vector3(2.05,.38,.55)

static func _build_grass(root:Node3D,p:Dictionary,map_id:String)->void:
    if map_id=="desert": return
    var count:=360 if OS.get_name()!="Android" else 170
    var mm:=MultiMesh.new(); mm.transform_format=MultiMesh.TRANSFORM_3D; mm.instance_count=count; mm.mesh=AnimaEnvironmentMeshes.grass_blade()
    var inst:=MultiMeshInstance3D.new(); inst.multimesh=mm; inst.material_override=AnimaFX.mat(p.accent.darkened(.35),0,.94,.0); root.add_child(inst)
    var rng:=RandomNumberGenerator.new(); rng.seed=hash(map_id)+881
    for i in range(count):
        var x:=rng.randf_range(-37.0,37.0); var z:=rng.randf_range(-37.0,37.0)
        if abs(x)<4.0 or abs(z)<4.0: x+=6.0
        var sc:=rng.randf_range(.55,1.35); var tr:=Transform3D(Basis(Vector3.UP,rng.randf_range(0,TAU)).scaled(Vector3(sc,sc,sc)),Vector3(x,.02,z)); mm.set_instance_transform(i,tr)

static func _build_atmosphere(root:Node3D,p:Dictionary,map_id:String)->void:
    var motes:=GPUParticles3D.new(); motes.amount=90; motes.lifetime=7.0; motes.preprocess=7.0; motes.visibility_aabb=AABB(Vector3(-38,0,-38),Vector3(76,14,76))
    var pm:=ParticleProcessMaterial.new(); pm.emission_shape=ParticleProcessMaterial.EMISSION_SHAPE_BOX; pm.emission_box_extents=Vector3(35,5,35); pm.direction=Vector3(.25,.7,.12); pm.spread=75.0
    pm.initial_velocity_min=.08; pm.initial_velocity_max=.34; pm.gravity=Vector3(0,.025,0); pm.scale_min=.35; pm.scale_max=1.0
    pm.color=Color(p.accent.r,p.accent.g,p.accent.b,.32 if map_id!="desert" else .18); motes.process_material=pm
    var q:=QuadMesh.new(); q.size=Vector2(.045,.045); q.material=AnimaFX.mat(Color(p.accent.r,p.accent.g,p.accent.b,.34),1.6,1.0)
    motes.draw_pass_1=q; root.add_child(motes); motes.position=Vector3(0,4,0)
    # Distant silhouettes make the arena feel like part of a larger world.
    for i in range(18):
        var a=TAU*float(i)/18.0; var dist=44.0+float(i%4)*4.0
        var h=8.0+float((i*7)%9); var peak:=CylinderMesh.new(); peak.top_radius=0.0; peak.bottom_radius=5.0+float(i%3); peak.height=h; peak.radial_segments=6
        var n=AnimaFX.primitive(peak,p.ground2.darkened(.28),0.0); root.add_child(n); n.position=Vector3(cos(a)*dist,h*.5-0.1,sin(a)*dist)

static func _ground_details(root:Node3D,p:Dictionary,map_id:String)->void:
    var rng:=RandomNumberGenerator.new(); rng.seed=hash(map_id)+7331
    for i in range(96):
        var x=rng.randf_range(-37,37); var z=rng.randf_range(-37,37)
        if abs(x)<3.2 or abs(z)<3.2:
            continue
        if map_id in ["grove","moon"]:
            var stem:=CylinderMesh.new(); stem.top_radius=.012; stem.bottom_radius=.018; stem.height=rng.randf_range(.18,.42); stem.radial_segments=5
            var col=p.accent.darkened(rng.randf_range(.05,.35))
            var g=AnimaFX.primitive(stem,Color(col.r,col.g,col.b,.72),.05); root.add_child(g); g.position=Vector3(x,stem.height*.5,z); g.rotation_degrees.z=rng.randf_range(-16,16)
        elif map_id=="desert":
            var peb:=SphereMesh.new(); peb.radius=rng.randf_range(.05,.14); peb.height=peb.radius*1.1
            var g=AnimaFX.primitive(peb,p.ground2.lightened(rng.randf_range(.02,.12)),0); root.add_child(g); g.position=Vector3(x,.04,z); g.scale=Vector3(rng.randf_range(.8,1.8),.45,rng.randf_range(.8,1.6))
        else:
            var shard:=BoxMesh.new(); shard.size=Vector3(rng.randf_range(.05,.12),rng.randf_range(.12,.32),rng.randf_range(.04,.09))
            var g=AnimaFX.primitive(shard,Color(p.accent.r,p.accent.g,p.accent.b,.44),.28); root.add_child(g); g.position=Vector3(x,shard.size.y*.5,z); g.rotation_degrees.y=rng.randf_range(0,180)

static func _build_weather(root:Node3D,p:Dictionary,map_id:String)->void:
    var weather:=GPUParticles3D.new()
    weather.amount=54 if map_id!="desert" else 34
    weather.lifetime=5.5
    weather.preprocess=5.5
    weather.visibility_aabb=AABB(Vector3(-40,-2,-40),Vector3(80,18,80))
    var pm:=ParticleProcessMaterial.new()
    pm.emission_shape=ParticleProcessMaterial.EMISSION_SHAPE_BOX
    pm.emission_box_extents=Vector3(34,7,34)
    pm.spread=38.0
    pm.scale_min=.65; pm.scale_max=1.35
    var q:=QuadMesh.new()
    match map_id:
        "grove":
            pm.direction=Vector3(.42,-.36,.18); pm.initial_velocity_min=.32; pm.initial_velocity_max=.82; pm.gravity=Vector3(0,-.18,0); pm.color=Color(1.0,.68,.82,.46); q.size=Vector2(.075,.14)
        "desert":
            pm.direction=Vector3(.8,.04,.28); pm.initial_velocity_min=.8; pm.initial_velocity_max=1.8; pm.gravity=Vector3(0,.0,0); pm.color=Color(1.0,.66,.38,.16); q.size=Vector2(.045,.18)
        "shrine":
            pm.direction=Vector3(.28,-.52,.08); pm.initial_velocity_min=.22; pm.initial_velocity_max=.62; pm.gravity=Vector3(0,-.25,0); pm.color=Color(.84,.96,1.0,.35); q.size=Vector2(.032,.12)
        _:
            pm.direction=Vector3(.18,-.22,.28); pm.initial_velocity_min=.16; pm.initial_velocity_max=.52; pm.gravity=Vector3(0,-.08,0); pm.color=Color(.68,.62,1.0,.32); q.size=Vector2(.04,.16)
    q.material=AnimaFX.mat(pm.color,1.4,.8,.0)
    weather.process_material=pm; weather.draw_pass_1=q; root.add_child(weather); weather.position=Vector3(0,8,0)
