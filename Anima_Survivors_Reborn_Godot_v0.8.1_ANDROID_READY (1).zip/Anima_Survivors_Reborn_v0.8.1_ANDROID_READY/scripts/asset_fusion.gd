class_name AnimaAssetFusion
extends Node

# Asset Fusion v0.8
# Swaps external GLB/GLTF assets into the production rigs without changing combat code.
# The procedural HUMANFORM rig remains the guaranteed fallback.

const HERO_PATHS := {
    "sakura": "res://assets/external/characters/sakura.glb",
    "kaito": "res://assets/external/characters/kaito.glb",
    "luna": "res://assets/external/characters/luna.glb",
    "ren": "res://assets/external/characters/ren.glb"
}
const MONSTER_PATHS := {
    "spirit": "res://assets/external/monsters/spirit.glb",
    "runner": "res://assets/external/monsters/runner.glb",
    "brute": "res://assets/external/monsters/brute.glb",
    "oracle": "res://assets/external/monsters/oracle.glb",
    "charger": "res://assets/external/monsters/charger.glb",
    "boss": "res://assets/external/monsters/boss.glb"
}

const HERO_SCALE := {"sakura":1.0,"kaito":1.03,"luna":0.98,"ren":1.04}
const MONSTER_SCALE := {"spirit":0.92,"runner":0.94,"brute":1.18,"oracle":1.0,"charger":1.12,"boss":1.55}

static func attach_hero(host: Node3D, hero_id: String, fallback_rig: AnimaCharacterRig) -> Dictionary:
    var result := {"external":false,"root":null,"anim":null,"skeleton":null,"face_meshes":[]}
    var path: String = HERO_PATHS.get(hero_id, "")
    if path.is_empty() or not ResourceLoader.exists(path):
        return result
    var packed = load(path)
    if packed == null or not (packed is PackedScene):
        return result
    var inst: Node = packed.instantiate()
    if not (inst is Node3D):
        inst.queue_free(); return result
    var root := inst as Node3D
    root.name = "ExternalHero_%s" % hero_id
    root.scale = Vector3.ONE * float(HERO_SCALE.get(hero_id,1.0))
    host.add_child(root)
    _normalize_import(root)
    var skel := _find_skeleton(root)
    var anim := _find_animation_player(root)
    var face := _find_face_meshes(root)
    _retint_character(root, hero_id)
    if is_instance_valid(fallback_rig.body_mesh): fallback_rig.body_mesh.visible=false
    _hide_procedural_detail(fallback_rig)
    result.external=true; result.root=root; result.anim=anim; result.skeleton=skel; result.face_meshes=face
    return result

static func attach_monster(host: Node3D, kind: String, is_boss: bool, fallback_rig: AnimaMonsterRig) -> Dictionary:
    var key := "boss" if is_boss else kind
    var result := {"external":false,"root":null,"anim":null,"skeleton":null}
    var path: String = MONSTER_PATHS.get(key, "")
    if path.is_empty() or not ResourceLoader.exists(path): return result
    var packed=load(path)
    if packed==null or not (packed is PackedScene): return result
    var inst:Node=packed.instantiate()
    if not (inst is Node3D): inst.queue_free(); return result
    var root:=inst as Node3D; root.name="ExternalMonster_%s"%key; root.scale=Vector3.ONE*float(MONSTER_SCALE.get(key,1.0)); host.add_child(root)
    _normalize_import(root)
    _hide_meshes(fallback_rig)
    result.external=true; result.root=root; result.anim=_find_animation_player(root); result.skeleton=_find_skeleton(root)
    return result

static func _normalize_import(root: Node3D) -> void:
    # glTF commonly imports in Y-up meters, but downloaded assets vary. We keep
    # the scene origin at feet and standardize material flags for our lighting.
    for node in root.find_children("*","MeshInstance3D",true,false):
        var mi:=node as MeshInstance3D
        mi.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON
        if mi.mesh:
            for s in range(mi.mesh.get_surface_count()):
                var mat=mi.mesh.surface_get_material(s)
                if mat is StandardMaterial3D:
                    mat=(mat as StandardMaterial3D).duplicate()
                    mat.roughness=clamp(mat.roughness,.28,.92)
                    mat.metallic=clamp(mat.metallic,0.0,1.0)
                    mi.set_surface_override_material(s,mat)

static func _retint_character(root:Node3D, hero_id:String)->void:
    var style=AnimaCharacterRig.HERO_STYLE.get(hero_id,AnimaCharacterRig.HERO_STYLE["sakura"])
    var primary:Color=style.primary; var accent:Color=style.accent
    for node in root.find_children("*","MeshInstance3D",true,false):
        var mi:=node as MeshInstance3D
        var lname:=mi.name.to_lower()
        if not mi.mesh: continue
        for s in range(mi.mesh.get_surface_count()):
            var mat=mi.get_active_material(s)
            if mat is StandardMaterial3D:
                var m:StandardMaterial3D=(mat as StandardMaterial3D).duplicate()
                if "cloth" in lname or "robe" in lname or "shirt" in lname or "armor" in lname:
                    m.albedo_color=m.albedo_color.lerp(primary,.28)
                elif "trim" in lname or "gem" in lname or "emiss" in lname:
                    m.albedo_color=m.albedo_color.lerp(accent,.38)
                    m.emission_enabled=true; m.emission=accent; m.emission_energy_multiplier=.8
                mi.set_surface_override_material(s,m)

static func _find_skeleton(root:Node)->Skeleton3D:
    if root is Skeleton3D: return root as Skeleton3D
    for c in root.get_children():
        var found:=_find_skeleton(c)
        if found: return found
    return null

static func _find_animation_player(root:Node)->AnimationPlayer:
    if root is AnimationPlayer: return root as AnimationPlayer
    for c in root.get_children():
        var found:=_find_animation_player(c)
        if found: return found
    return null

static func _find_face_meshes(root:Node)->Array:
    var out:=[]
    for n in root.find_children("*","MeshInstance3D",true,false):
        var mi:=n as MeshInstance3D
        var ln:=mi.name.to_lower()
        if "face" in ln or "head" in ln or "body" in ln: out.append(mi)
    return out

static func _hide_meshes(root:Node)->void:
    for n in root.find_children("*","MeshInstance3D",true,false): (n as MeshInstance3D).visible=false

static func _hide_procedural_detail(rig:AnimaCharacterRig)->void:
    # Keep skeleton/attachments alive because weapons and gameplay sockets use them.
    for n in rig.find_children("*","MeshInstance3D",true,false):
        (n as MeshInstance3D).visible=false

static func play_by_hint(player:AnimationPlayer, hints:Array[String], blend:float=.14, speed:float=1.0, loop_if_possible:bool=true)->String:
    if not is_instance_valid(player): return ""
    var libraries:=player.get_animation_library_list()
    for lib_name in libraries:
        var lib:=player.get_animation_library(lib_name)
        if not lib: continue
        for anim_name in lib.get_animation_list():
            var lower:=anim_name.to_lower()
            for hint in hints:
                if hint.to_lower() in lower:
                    var full_name:=String(anim_name) if String(lib_name).is_empty() else "%s/%s"%[lib_name,anim_name]
                    if player.current_animation!=full_name:
                        player.play(full_name,blend,speed)
                    return full_name
    return ""

static func set_face_value(face_meshes:Array, hints:Array[String], value:float)->void:
    for mi in face_meshes:
        if not is_instance_valid(mi) or not mi.mesh: continue
        var count:=mi.mesh.get_blend_shape_count()
        for i in range(count):
            var name:=String(mi.mesh.get_blend_shape_name(i)).to_lower()
            for hint in hints:
                if hint.to_lower() in name:
                    mi.set_blend_shape_value(i,value)
