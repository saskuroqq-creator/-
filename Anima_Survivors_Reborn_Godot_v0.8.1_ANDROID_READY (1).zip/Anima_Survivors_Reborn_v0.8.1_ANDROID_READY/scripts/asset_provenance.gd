class_name AnimaAssetProvenance
extends RefCounted

const VERIFIED_FREE_SOURCES := [
    {
        "name":"Blender Human Base Meshes v1.4.1",
        "role":"high-detail human sculpt/base topology",
        "license":"CC0 1.0",
        "url":"https://www.blender.org/download/demo-files/",
        "redistribution":"allowed"
    },
    {
        "name":"Quaternius Universal Animation Library",
        "role":"humanoid locomotion/combat/spell/death animation",
        "license":"CC0 1.0",
        "url":"https://quaternius.com/packs/universalanimationlibrary.html",
        "redistribution":"allowed for Standard CC0 files"
    },
    {
        "name":"Quaternius Universal Animation Library 2",
        "role":"melee combos/root-motion/parkour/zombie motion",
        "license":"CC0 1.0",
        "url":"https://quaternius.com/packs/universalanimationlibrary2.html",
        "redistribution":"allowed for Standard CC0 files"
    },
    {
        "name":"Poly Haven",
        "role":"photogrammetry rocks, surfaces, foliage, HDRI",
        "license":"CC0 1.0",
        "url":"https://polyhaven.com/",
        "redistribution":"allowed"
    },
    {
        "name":"Gobkit Free Minions",
        "role":"CC0 animated enemy fallback / retarget test",
        "license":"CC0 1.0",
        "url":"https://gobkit.itch.io/gobkit-free-minions",
        "redistribution":"allowed"
    }
]
