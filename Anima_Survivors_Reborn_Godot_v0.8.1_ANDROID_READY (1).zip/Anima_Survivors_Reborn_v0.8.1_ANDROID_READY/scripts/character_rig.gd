class_name AnimaCharacterRig
extends Node3D

# Procedural skinned character used by the production branch.
# The body is an ArrayMesh with bone indices/weights driven by a Skeleton3D.
# Detail meshes (face, hair, armor and weapon) ride on bone attachments.

var hero_id := "sakura"
var skeleton: Skeleton3D
var body_mesh: MeshInstance3D
var weapon_socket: BoneAttachment3D
var head_socket: BoneAttachment3D
var chest_socket: BoneAttachment3D
var hip_socket: BoneAttachment3D
var bones := {}
var accent := Color(0.35, 0.95, 1.0)
var primary := Color(0.82, 0.18, 0.42)
var skin_color := Color(0.92, 0.67, 0.54)
var gait_phase := 0.0
var idle_phase := 0.0
var cloth_phase := 0.0
var cape: MeshInstance3D
var hair_root: Node3D
var eye_nodes: Array[MeshInstance3D] = []
var blink_clock := 2.4
var blink_phase := 0.0

const HERO_STYLE := {
    "sakura": {"primary": Color(0.72,0.10,0.35), "accent": Color(0.38,0.95,1.0), "skin": Color(0.93,0.69,0.58), "hair": Color(0.08,0.035,0.06), "armor": Color(0.12,0.14,0.18)},
    "kaito":  {"primary": Color(0.10,0.23,0.58), "accent": Color(0.98,0.26,0.72), "skin": Color(0.84,0.61,0.49), "hair": Color(0.03,0.04,0.07), "armor": Color(0.11,0.18,0.28)},
    "luna":   {"primary": Color(0.30,0.18,0.58), "accent": Color(1.0,0.80,0.26), "skin": Color(0.88,0.66,0.56), "hair": Color(0.77,0.80,0.90), "armor": Color(0.22,0.23,0.32)},
    "ren":    {"primary": Color(0.52,0.08,0.07), "accent": Color(1.0,0.52,0.18), "skin": Color(0.86,0.60,0.47), "hair": Color(0.06,0.025,0.02), "armor": Color(0.20,0.09,0.06)}
}

func build(id: String, scale_mul: float = 1.0) -> void:
    hero_id = id
    var style: Dictionary = HERO_STYLE.get(id, HERO_STYLE["sakura"])
    primary = style.primary
    accent = style.accent
    skin_color = style.skin
    scale = Vector3.ONE * scale_mul
    skeleton = Skeleton3D.new()
    skeleton.name = "ProductionSkeleton"
    add_child(skeleton)
    _build_skeleton()
    _build_body(style)
    _build_face(style)
    _build_hair(style)
    _build_clothing(style)
    _build_hero_identity(style)
    _build_weapon(style)
    _reset_pose()

func _build_skeleton() -> void:
    var defs := [
        ["root", -1, Vector3(0,0,0)],
        ["hips", 0, Vector3(0,.92,0)],
        ["spine", 1, Vector3(0,.25,0)],
        ["chest", 2, Vector3(0,.29,0)],
        ["neck", 3, Vector3(0,.30,0)],
        ["head", 4, Vector3(0,.18,0)],
        ["upper_arm_l", 3, Vector3(-.36,.22,0)],
        ["forearm_l", 6, Vector3(0,-.34,0)],
        ["hand_l", 7, Vector3(0,-.30,0)],
        ["upper_arm_r", 3, Vector3(.36,.22,0)],
        ["forearm_r", 9, Vector3(0,-.34,0)],
        ["hand_r", 10, Vector3(0,-.30,0)],
        ["thigh_l", 1, Vector3(-.18,-.06,0)],
        ["calf_l", 12, Vector3(0,-.45,0)],
        ["foot_l", 13, Vector3(0,-.43,-.04)],
        ["thigh_r", 1, Vector3(.18,-.06,0)],
        ["calf_r", 15, Vector3(0,-.45,0)],
        ["foot_r", 16, Vector3(0,-.43,-.04)]
    ]
    for d in defs:
        var idx := skeleton.add_bone(d[0])
        bones[d[0]] = idx
        skeleton.set_bone_parent(idx, d[1])
        skeleton.set_bone_rest(idx, Transform3D(Basis.IDENTITY, d[2]))

func _surface() -> Dictionary:
    return {
        "v": PackedVector3Array(), "n": PackedVector3Array(), "uv": PackedVector2Array(),
        "b": PackedInt32Array(), "w": PackedFloat32Array(), "i": PackedInt32Array()
    }

func _push_vertex(s: Dictionary, p: Vector3, normal: Vector3, uv: Vector2, bone_a: int, bone_b: int = -1, blend: float = 0.0) -> int:
    var idx: int = s.v.size()
    s.v.append(p); s.n.append(normal.normalized()); s.uv.append(uv)
    s.b.append(bone_a); s.b.append(bone_b if bone_b >= 0 else bone_a); s.b.append(0); s.b.append(0)
    var bw := clamp(blend, 0.0, 1.0) if bone_b >= 0 else 0.0
    s.w.append(1.0-bw); s.w.append(bw); s.w.append(0.0); s.w.append(0.0)
    return idx

func _basis_for_axis(axis: Vector3) -> Array:
    var a := axis.normalized()
    var helper := Vector3.UP if abs(a.dot(Vector3.UP)) < .92 else Vector3.RIGHT
    var u := a.cross(helper).normalized()
    var v := a.cross(u).normalized()
    return [u,v]

func _add_tube(s: Dictionary, a: Vector3, b: Vector3, r0: float, r1: float, bone_a: int, bone_b: int, sides: int = 12, rings: int = 4) -> void:
    var axis := b-a
    var frame := _basis_for_axis(axis)
    var u: Vector3 = frame[0]; var v: Vector3 = frame[1]
    var base := s.v.size()
    for r in range(rings+1):
        var t := float(r)/float(rings)
        var center := a.lerp(b,t)
        var radius := lerp(r0,r1,t) * (1.0 + sin(t*PI)*.055)
        for j in range(sides):
            var ang := TAU*float(j)/float(sides)
            var radial := (u*cos(ang)+v*sin(ang)).normalized()
            _push_vertex(s, center+radial*radius, radial, Vector2(float(j)/float(sides),t), bone_a, bone_b, t)
    for r in range(rings):
        for j in range(sides):
            var nj := (j+1)%sides
            var i0 := base+r*sides+j
            var i1 := base+r*sides+nj
            var i2 := base+(r+1)*sides+j
            var i3 := base+(r+1)*sides+nj
            s.i.append(i0); s.i.append(i2); s.i.append(i1)
            s.i.append(i1); s.i.append(i2); s.i.append(i3)

func _add_ellipsoid(s: Dictionary, center: Vector3, radii: Vector3, bone: int, rings: int = 10, sides: int = 14) -> void:
    var base := s.v.size()
    for y in range(rings+1):
        var fy := float(y)/float(rings)
        var phi := PI*fy
        for x in range(sides):
            var fx := float(x)/float(sides)
            var theta := TAU*fx
            var unit := Vector3(sin(phi)*cos(theta), cos(phi), sin(phi)*sin(theta))
            var p := center + Vector3(unit.x*radii.x, unit.y*radii.y, unit.z*radii.z)
            var normal := Vector3(unit.x/max(.001,radii.x), unit.y/max(.001,radii.y), unit.z/max(.001,radii.z)).normalized()
            _push_vertex(s,p,normal,Vector2(fx,fy),bone)
    for y in range(rings):
        for x in range(sides):
            var nx := (x+1)%sides
            var i0 := base+y*sides+x; var i1 := base+y*sides+nx
            var i2 := base+(y+1)*sides+x; var i3 := base+(y+1)*sides+nx
            s.i.append(i0); s.i.append(i2); s.i.append(i1)
            s.i.append(i1); s.i.append(i2); s.i.append(i3)

func _commit(mesh: ArrayMesh, s: Dictionary, material: Material) -> void:
    if s.v.is_empty(): return
    var arrays := []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = s.v
    arrays[Mesh.ARRAY_NORMAL] = s.n
    arrays[Mesh.ARRAY_TEX_UV] = s.uv
    arrays[Mesh.ARRAY_BONES] = s.b
    arrays[Mesh.ARRAY_WEIGHTS] = s.w
    arrays[Mesh.ARRAY_INDEX] = s.i
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    mesh.surface_set_material(mesh.get_surface_count()-1, material)

func _material(c: Color, rough: float = .58, metal: float = 0.0, emission: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    m.metallic = metal
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    if emission > 0.0:
        m.emission_enabled = true; m.emission = c; m.emission_energy_multiplier = emission
    return m

func _skin_material(c:Color)->ShaderMaterial:
    var m:=ShaderMaterial.new(); m.shader=load("res://shaders/skin_realistic.gdshader"); m.set_shader_parameter("skin_tint",c); return m

func _hair_material(c:Color)->ShaderMaterial:
    var m:=ShaderMaterial.new(); m.shader=load("res://shaders/hair_aniso.gdshader"); m.set_shader_parameter("hair_tint",c); m.set_shader_parameter("sheen_tint",c.lightened(.34)); return m

func _build_body(style: Dictionary) -> void:
    var cloth := _surface(); var skin := _surface(); var boots := _surface()
    var hip := skeleton.get_bone_global_rest(bones.hips).origin
    var spine := skeleton.get_bone_global_rest(bones.spine).origin
    var chest := skeleton.get_bone_global_rest(bones.chest).origin
    var neck := skeleton.get_bone_global_rest(bones.neck).origin
    var head := skeleton.get_bone_global_rest(bones.head).origin
    _add_tube(cloth, hip+Vector3(0,-.06,0), spine, .27,.30,bones.hips,bones.spine,14,4)
    _add_tube(cloth, spine, chest+Vector3(0,.14,0), .30,.37,bones.spine,bones.chest,14,5)
    _add_tube(skin, neck, head-Vector3(0,.03,0), .105,.115,bones.neck,bones.head,10,2)
    _add_ellipsoid(skin, head+Vector3(0,.14,-.015), Vector3(.245,.30,.225), bones.head,11,16)
    # Arms and hands.
    for side in ["l","r"]:
        var ua: int = bones["upper_arm_"+side]; var fa: int = bones["forearm_"+side]; var ha: int = bones["hand_"+side]
        var a := skeleton.get_bone_global_rest(ua).origin; var b := skeleton.get_bone_global_rest(fa).origin; var c := skeleton.get_bone_global_rest(ha).origin
        _add_tube(cloth,a,b,.105,.095,ua,fa,10,4); _add_tube(cloth,b,c,.092,.075,fa,ha,10,4)
        _add_ellipsoid(skin,c+Vector3(0,-.065,0),Vector3(.085,.105,.075),ha,7,10)
    # Legs and feet.
    for side in ["l","r"]:
        var th: int = bones["thigh_"+side]; var ca: int = bones["calf_"+side]; var ft: int = bones["foot_"+side]
        var a := skeleton.get_bone_global_rest(th).origin; var b := skeleton.get_bone_global_rest(ca).origin; var c := skeleton.get_bone_global_rest(ft).origin
        _add_tube(cloth,a,b,.145,.118,th,ca,12,4); _add_tube(cloth,b,c,.115,.092,ca,ft,12,4)
        _add_tube(boots,c,c+Vector3(0,-.08,-.18),.105,.135,ft,ft,10,2)
    var mesh := ArrayMesh.new()
    _commit(mesh,cloth,_material(primary.darkened(.18),.72,.04))
    _commit(mesh,skin,_skin_material(skin_color))
    _commit(mesh,boots,_material(Color(.035,.035,.045),.44,.28))
    body_mesh=MeshInstance3D.new(); body_mesh.name="SkinnedBody"; body_mesh.mesh=mesh
    skeleton.add_child(body_mesh); body_mesh.skeleton=NodePath("..")
    body_mesh.skin=skeleton.create_skin_from_rest_transforms()
    body_mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON

func _attachment(name: String, bone_name: String) -> BoneAttachment3D:
    var a := BoneAttachment3D.new(); a.name=name; a.bone_name=bone_name; skeleton.add_child(a); return a

func _build_face(style: Dictionary) -> void:
    head_socket=_attachment("HeadSocket","head")
    # Bone attachment origin is the head bone; details are offset around the head volume.
    var eye_mat := _material(Color(.96,.98,1.0),.22,.0)
    var iris_mat := _material(accent, .18,.05,1.8)
    for sx in [-1.0,1.0]:
        var e:=SphereMesh.new(); e.radius=.048; e.height=.096
        var en:=MeshInstance3D.new(); en.mesh=e; en.material_override=eye_mat; head_socket.add_child(en); en.position=Vector3(.085*sx,.135,-.215); eye_nodes.append(en)
        var iris:=SphereMesh.new(); iris.radius=.022; iris.height=.044
        var inn:=MeshInstance3D.new(); inn.mesh=iris; inn.material_override=iris_mat; head_socket.add_child(inn); inn.position=Vector3(.085*sx,.135,-.257)
    var brow_mesh:=BoxMesh.new(); brow_mesh.size=Vector3(.095,.018,.018)
    for sx in [-1.0,1.0]:
        var b:=MeshInstance3D.new(); b.mesh=brow_mesh; b.material_override=_material(style.hair,.72); head_socket.add_child(b); b.position=Vector3(.085*sx,.205,-.242); b.rotation.z=.12*sx
    var mouth:=BoxMesh.new(); mouth.size=Vector3(.075,.012,.012)
    var mn:=MeshInstance3D.new(); mn.mesh=mouth; mn.material_override=_material(Color(.32,.09,.10),.62); head_socket.add_child(mn); mn.position=Vector3(0,.02,-.255)
    var nose:=CylinderMesh.new(); nose.top_radius=.012; nose.bottom_radius=.035; nose.height=.09; nose.radial_segments=6
    var nn:=MeshInstance3D.new(); nn.mesh=nose; nn.material_override=_material(skin_color.darkened(.04),.57); head_socket.add_child(nn); nn.position=Vector3(0,.09,-.26); nn.rotation_degrees.x=90
    for sx in [-1.0,1.0]:
        var ear:=SphereMesh.new(); ear.radius=.043; ear.height=.085
        var ear_n:=MeshInstance3D.new(); ear_n.mesh=ear; ear_n.material_override=_material(skin_color.darkened(.03),.58); head_socket.add_child(ear_n); ear_n.position=Vector3(.245*sx,.115,-.005); ear_n.scale=Vector3(.55,1.0,.45)

func _build_hair(style: Dictionary) -> void:
    hair_root=Node3D.new(); hair_root.name="Hair"; head_socket.add_child(hair_root)
    var hair_mat:=_hair_material(style.hair)
    # Layered clumps produce a readable hair silhouette without external assets.
    for i in range(12):
        var ang:=TAU*float(i)/12.0
        var clump:=CylinderMesh.new(); clump.top_radius=.025; clump.bottom_radius=.075; clump.height=.34; clump.radial_segments=6
        var n:=MeshInstance3D.new(); n.mesh=clump; n.material_override=hair_mat; hair_root.add_child(n)
        n.position=Vector3(cos(ang)*.18,.27,sin(ang)*.17+.015); n.rotation=Vector3(sin(ang)*.28,0,-cos(ang)*.28)
    var cap:=SphereMesh.new(); cap.radius=.258; cap.height=.43
    var capn:=MeshInstance3D.new(); capn.mesh=cap; capn.material_override=hair_mat; hair_root.add_child(capn); capn.position=Vector3(0,.25,.02); capn.scale=Vector3(1.03,.68,1.04)

func _build_clothing(style: Dictionary) -> void:
    chest_socket=_attachment("ChestSocket","chest"); hip_socket=_attachment("HipSocket","hips")
    var armor_mat:=_material(style.armor,.36,.62)
    for sx in [-1.0,1.0]:
        var plate:=BoxMesh.new(); plate.size=Vector3(.18,.12,.28)
        var pn:=MeshInstance3D.new(); pn.mesh=plate; pn.material_override=armor_mat; chest_socket.add_child(pn); pn.position=Vector3(.22*sx,.05,-.19); pn.rotation.z=.18*sx
    var belt:=TorusMesh.new(); belt.inner_radius=.235; belt.outer_radius=.285; belt.rings=24; belt.ring_segments=8
    var bn:=MeshInstance3D.new(); bn.mesh=belt; bn.material_override=_material(Color(.10,.06,.045),.64,.18); hip_socket.add_child(bn); bn.rotation_degrees.x=90; bn.position.y=.02
    # Cape/coat tail is a tapered custom mesh and reacts to velocity in animate_player().
    cape=MeshInstance3D.new(); cape.name="ClothTail"; cape.mesh=_cloth_panel_mesh(); cape.material_override=_material(primary.darkened(.28),.86,.0); hip_socket.add_child(cape); cape.position=Vector3(0,-.02,.18)

func _cloth_panel_mesh() -> ArrayMesh:
    var verts:=PackedVector3Array([Vector3(-.28,.08,0),Vector3(.28,.08,0),Vector3(-.42,-.72,.10),Vector3(.42,-.72,.10)])
    var normals:=PackedVector3Array([Vector3.BACK,Vector3.BACK,Vector3.BACK,Vector3.BACK])
    var uvs:=PackedVector2Array([Vector2(0,0),Vector2(1,0),Vector2(0,1),Vector2(1,1)])
    var idx:=PackedInt32Array([0,2,1,1,2,3])
    var arrays:=[]; arrays.resize(Mesh.ARRAY_MAX); arrays[Mesh.ARRAY_VERTEX]=verts; arrays[Mesh.ARRAY_NORMAL]=normals; arrays[Mesh.ARRAY_TEX_UV]=uvs; arrays[Mesh.ARRAY_INDEX]=idx
    var mesh:=ArrayMesh.new(); mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays); return mesh

func _build_hero_identity(style: Dictionary) -> void:
    var metal:=_material(style.armor,.30,.72)
    match hero_id:
        "sakura":
            # Layered shrine-warrior skirt and shoulder crest.
            var skirt:=_attachment("SakuraSkirt","hips")
            for sx in [-1.0,1.0]:
                var panel:=MeshInstance3D.new(); panel.mesh=_cloth_panel_mesh(); panel.material_override=_material(primary,.84,.02); skirt.add_child(panel); panel.position=Vector3(.18*sx,-.02,.04); panel.scale=Vector3(.58,.88,1.0); panel.rotation.z=.06*sx
            var crest:=_attachment("SakuraCrest","chest")
            var gem:=SphereMesh.new(); gem.radius=.055; gem.height=.11
            var gn:=MeshInstance3D.new(); gn.mesh=gem; gn.material_override=_material(accent,.18,.12,3.5); crest.add_child(gn); gn.position=Vector3(0,.08,-.235)
        "kaito":
            var chest:=_attachment("KaitoJacket","chest")
            var vest:=BoxMesh.new(); vest.size=Vector3(.56,.42,.16)
            var vn:=MeshInstance3D.new(); vn.mesh=vest; vn.material_override=metal; chest.add_child(vn); vn.position=Vector3(0,-.01,-.20)
            var visor:=BoxMesh.new(); visor.size=Vector3(.20,.045,.025)
            var vis:=MeshInstance3D.new(); vis.mesh=visor; vis.material_override=_material(accent,.12,.20,2.8); head_socket.add_child(vis); vis.position=Vector3(0,.15,-.267)
        "luna":
            var mantle:=_attachment("LunaMantle","chest")
            var ring:=TorusMesh.new(); ring.inner_radius=.30; ring.outer_radius=.36; ring.rings=28; ring.ring_segments=8
            var rn:=MeshInstance3D.new(); rn.mesh=ring; rn.material_override=_material(primary.lightened(.12),.55,.08); mantle.add_child(rn); rn.rotation_degrees.x=90; rn.position=Vector3(0,.11,0)
            var halo:=TorusMesh.new(); halo.inner_radius=.23; halo.outer_radius=.255; halo.rings=32; halo.ring_segments=6
            var hn:=MeshInstance3D.new(); hn.mesh=halo; hn.material_override=_material(accent,.16,.18,3.0); head_socket.add_child(hn); hn.position=Vector3(0,.38,.06); hn.rotation_degrees.x=90
        "ren":
            var scarf:=_attachment("RenScarf","neck")
            var scarf_mesh:=TorusMesh.new(); scarf_mesh.inner_radius=.12; scarf_mesh.outer_radius=.18; scarf_mesh.rings=24; scarf_mesh.ring_segments=8
            var sn:=MeshInstance3D.new(); sn.mesh=scarf_mesh; sn.material_override=_material(primary.lightened(.08),.90,.0); scarf.add_child(sn); sn.rotation_degrees.x=90
            var tail:=MeshInstance3D.new(); tail.mesh=_cloth_panel_mesh(); tail.material_override=_material(primary,.92,.0); scarf.add_child(tail); tail.position=Vector3(.10,-.05,.12); tail.scale=Vector3(.32,.68,1.0); tail.rotation.z=-.22
            var gauntlet:=_attachment("RenGauntlet","forearm_l")
            var gm:=CylinderMesh.new(); gm.top_radius=.095; gm.bottom_radius=.11; gm.height=.25; gm.radial_segments=10
            var g:=MeshInstance3D.new(); g.mesh=gm; g.material_override=metal; gauntlet.add_child(g); g.position=Vector3(0,-.16,0)

func _build_weapon(style: Dictionary) -> void:
    weapon_socket=_attachment("WeaponSocket","hand_r")
    var root:=Node3D.new(); root.name="HeroWeapon"; weapon_socket.add_child(root); root.position=Vector3(0,-.06,-.04)
    var metal:=_material(Color(.62,.72,.78),.18,.88)
    var glow:=_material(accent,.20,.22,3.2)
    if hero_id=="luna":
        var shaft:=CylinderMesh.new(); shaft.top_radius=.025; shaft.bottom_radius=.035; shaft.height=.95; shaft.radial_segments=8
        var sn:=MeshInstance3D.new(); sn.mesh=shaft; sn.material_override=metal; root.add_child(sn); sn.position=Vector3(0,-.42,0)
        var orb:=SphereMesh.new(); orb.radius=.10; orb.height=.20; var on:=MeshInstance3D.new(); on.mesh=orb; on.material_override=glow; root.add_child(on); on.position=Vector3(0,-.93,0)
    elif hero_id=="kaito":
        var core:=BoxMesh.new(); core.size=Vector3(.12,.07,.62); var c:=MeshInstance3D.new(); c.mesh=core; c.material_override=glow; root.add_child(c); c.position=Vector3(0,-.10,-.27); c.rotation_degrees.x=68
    else:
        var blade:=BoxMesh.new(); blade.size=Vector3(.045,.025,1.0 if hero_id=="sakura" else 1.16); var bn:=MeshInstance3D.new(); bn.mesh=blade; bn.material_override=metal; root.add_child(bn); bn.position=Vector3(.02,-.12,-.43); bn.rotation_degrees.x=72
        var edge:=BoxMesh.new(); edge.size=Vector3(.012,.035,.86 if hero_id=="sakura" else 1.02); var en:=MeshInstance3D.new(); en.mesh=edge; en.material_override=glow; root.add_child(en); en.position=Vector3(-.015,-.115,-.44); en.rotation_degrees.x=72

func _reset_pose() -> void:
    skeleton.reset_bone_poses()

func _q(euler: Vector3) -> Quaternion:
    return Basis.from_euler(euler).get_rotation_quaternion()

func _pose(name: String, rot: Vector3, delta: float, speed: float = 14.0) -> void:
    var idx: int = bones.get(name,-1)
    if idx<0: return
    var current:=skeleton.get_bone_pose_rotation(idx)
    skeleton.set_bone_pose_rotation(idx,current.slerp(_q(rot),1.0-exp(-speed*delta)))

func animate_player(delta: float, velocity: Vector3, move_speed: float, dash_weight: float, attack_pose: float, cast_pose: float, hit_pose: float, attack_style: String, acceleration: Vector3, turn_bank: float) -> void:
    blink_clock-=delta
    if blink_clock<=0.0 and blink_phase<=0.0:
        blink_phase=.18; blink_clock=2.0+fmod(abs(sin(idle_phase*1.73))*2.4,2.4)
    blink_phase=max(0.0,blink_phase-delta)
    var blink_scale:=.10 if blink_phase>.08 else (lerp(.10,1.0,clamp((.08-blink_phase)/.08,0.0,1.0)) if blink_phase>0.0 else 1.0)
    for eye in eye_nodes:
        if is_instance_valid(eye): eye.scale.y=blink_scale
    var speed_ratio:=clamp(Vector2(velocity.x,velocity.z).length()/max(.01,move_speed),0.0,1.6)
    var moving:=speed_ratio>.06
    idle_phase+=delta*(2.0 if not moving else 3.1); gait_phase+=delta*(4.5+8.2*speed_ratio); cloth_phase+=delta*3.2
    var gait:=sin(gait_phase)*.62*clamp(speed_ratio,0.0,1.0)
    var step_y:=max(0.0,sin(gait_phase*2.0))*.018*speed_ratio
    var attack_curve:=sin(clamp(attack_pose,0.0,1.0)*PI)
    var cast_curve:=sin(clamp(cast_pose,0.0,1.0)*PI)
    var breath:=sin(idle_phase)*.018
    var hip_twist:=sin(gait_phase)*.07*speed_ratio
    _pose("hips",Vector3(0,hip_twist*.18,-turn_bank*.28),delta,11)
    _pose("spine",Vector3(-speed_ratio*.035+hit_pose*.08,hip_twist*.42,-turn_bank*.36),delta,10)
    _pose("chest",Vector3(-dash_weight*.12-attack_curve*.06,-hip_twist*.48,-turn_bank*.28),delta,12)
    _pose("neck",Vector3(.02+breath*.25,hit_pose*.04,turn_bank*.15),delta,10)
    _pose("head",Vector3(-.02-hit_pose*.08,-hip_twist*.2,turn_bank*.18),delta,9)
    var left_arm:= -gait*.50 + cast_curve*.82
    var right_arm:= gait*.34 - attack_curve*1.28 + cast_curve*.35
    var right_roll:=0.0
    if attack_style=="whip": right_arm-=attack_curve*.42; right_roll=-attack_curve*.85
    elif attack_style=="shard": right_arm-=attack_curve*.22; right_roll=attack_curve*.20
    elif attack_style in ["ring","thunder","owls","ultimate"]: left_arm+=cast_curve*.46; right_arm+=cast_curve*.50
    if dash_weight>0.0: left_arm=-.65; right_arm=-.72
    _pose("upper_arm_l",Vector3(left_arm,0,-.10-cast_curve*.22),delta,16)
    _pose("forearm_l",Vector3(-.10-cast_curve*.42,0,.05),delta,16)
    _pose("hand_l",Vector3(0,cast_curve*.18,0),delta,15)
    _pose("upper_arm_r",Vector3(right_arm,right_roll,.10+attack_curve*.16),delta,18)
    _pose("forearm_r",Vector3(-.14-attack_curve*.52,0,-right_roll*.22),delta,19)
    _pose("hand_r",Vector3(-attack_curve*.12,0,right_roll*.26),delta,18)
    var leg_boost:=1.0+dash_weight*.25
    _pose("thigh_l",Vector3(gait*leg_boost,0,.02),delta,15); _pose("thigh_r",Vector3(-gait*leg_boost,0,-.02),delta,15)
    _pose("calf_l",Vector3(max(0.0,-gait)*.42,0,0),delta,15); _pose("calf_r",Vector3(max(0.0,gait)*.42,0,0),delta,15)
    _pose("foot_l",Vector3(-max(0.0,gait)*.20,0,0),delta,13); _pose("foot_r",Vector3(-max(0.0,-gait)*.20,0,0),delta,13)
    skeleton.set_bone_pose_position(bones.hips,Vector3(0,step_y+breath*.18,0))
    if is_instance_valid(cape):
        cape.rotation.x=lerp(cape.rotation.x,.10+speed_ratio*.38+dash_weight*.28,1.0-exp(-6.0*delta))
        cape.rotation.z=lerp(cape.rotation.z,-velocity.x*.045+sin(cloth_phase)*.025,1.0-exp(-5.0*delta))
    if is_instance_valid(hair_root):
        hair_root.rotation.x=lerp(hair_root.rotation.x,speed_ratio*.035,1.0-exp(-4.5*delta))
        hair_root.rotation.z=lerp(hair_root.rotation.z,-turn_bank*.25,1.0-exp(-5.5*delta))

func animate_enemy(delta: float, velocity: Vector3, move_speed: float, attack_pose: float, cast_pose: float, hit_pose: float, boss_weight: float = 0.0) -> void:
    var speed_ratio:=clamp(Vector2(velocity.x,velocity.z).length()/max(.01,move_speed),0.0,1.5)
    gait_phase+=delta*(4.2+7.0*speed_ratio); idle_phase+=delta*2.0
    var gait:=sin(gait_phase)*.52*clamp(speed_ratio,0.0,1.0)
    var attack_curve:=sin(clamp(attack_pose,0.0,1.0)*PI)
    var cast_curve:=sin(clamp(cast_pose,0.0,1.0)*PI)
    _pose("hips",Vector3(0,sin(gait_phase)*.035*speed_ratio,0),delta,10)
    _pose("spine",Vector3(.06+hit_pose*.12,0,-velocity.x*.018),delta,11)
    _pose("chest",Vector3(-attack_curve*.14,0,0),delta,12)
    _pose("head",Vector3(-.03-hit_pose*.16,0,0),delta,11)
    _pose("thigh_l",Vector3(gait,0,0),delta,14); _pose("thigh_r",Vector3(-gait,0,0),delta,14)
    _pose("calf_l",Vector3(max(0.0,-gait)*.38,0,0),delta,14); _pose("calf_r",Vector3(max(0.0,gait)*.38,0,0),delta,14)
    _pose("upper_arm_l",Vector3(-gait*.24-attack_curve*.85+cast_curve*.90,0,-.15),delta,15)
    _pose("upper_arm_r",Vector3(gait*.24-attack_curve*1.1+cast_curve*.90,0,.15),delta,15)
    _pose("forearm_l",Vector3(-.18-attack_curve*.35,0,0),delta,15); _pose("forearm_r",Vector3(-.18-attack_curve*.45,0,0),delta,15)
    skeleton.set_bone_pose_position(bones.hips,Vector3(0,sin(gait_phase*2.0)*.012*speed_ratio,0))
    if is_instance_valid(cape): cape.rotation.x=lerp(cape.rotation.x,.20+speed_ratio*.20+boss_weight*.08,1.0-exp(-5.0*delta))
