class_name AnimaMonsterRig
extends AnimaCharacterRig

var kind := "spirit"
var boss_mode := false

const MONSTER_STYLE := {
    "spirit":  {"primary":Color(.10,.055,.17),"accent":Color(.64,.20,.85),"skin":Color(.23,.16,.31),"hair":Color(.04,.02,.06),"armor":Color(.13,.07,.18)},
    "runner":  {"primary":Color(.18,.035,.10),"accent":Color(1.0,.22,.60),"skin":Color(.30,.13,.20),"hair":Color(.04,.015,.025),"armor":Color(.24,.05,.12)},
    "brute":   {"primary":Color(.20,.06,.025),"accent":Color(1.0,.33,.10),"skin":Color(.34,.17,.10),"hair":Color(.05,.02,.01),"armor":Color(.28,.10,.04)},
    "oracle":  {"primary":Color(.025,.15,.19),"accent":Color(.15,.88,1.0),"skin":Color(.16,.25,.28),"hair":Color(.02,.06,.07),"armor":Color(.05,.22,.28)},
    "charger": {"primary":Color(.24,.10,.025),"accent":Color(1.0,.57,.16),"skin":Color(.31,.19,.10),"hair":Color(.06,.025,.01),"armor":Color(.32,.13,.04)}
}

func build_monster(monster_kind: String, is_boss: bool = false) -> void:
    kind=monster_kind; boss_mode=is_boss; hero_id="monster"
    var style: Dictionary = MONSTER_STYLE.get(kind,MONSTER_STYLE.spirit)
    primary=style.primary; accent=style.accent; skin_color=style.skin
    if boss_mode:
        scale=Vector3(1.82,2.08,1.82)
    elif kind=="brute":
        scale=Vector3(1.22,1.16,1.22)
    elif kind=="runner":
        scale=Vector3(.82,1.10,.82)
    elif kind=="oracle":
        scale=Vector3(.92,1.04,.92)
    elif kind=="charger":
        scale=Vector3(1.08,1.02,1.18)
    else:
        scale=Vector3.ONE
    skeleton=Skeleton3D.new(); skeleton.name="MonsterSkeleton"; add_child(skeleton)
    _build_skeleton(); _build_body(style); _build_monster_head(style); _build_monster_armor(style)
    _build_species_details(style)
    if kind=="oracle": _build_oracle_focus()
    _reset_pose()

func _build_monster_head(style: Dictionary) -> void:
    head_socket=_attachment("MonsterHead","head")
    var mask_mat:=_material(Color(.025,.025,.035),.35,.62)
    var mask:=SphereMesh.new(); mask.radius=.235; mask.height=.42
    var mn:=MeshInstance3D.new(); mn.mesh=mask; mn.material_override=mask_mat; head_socket.add_child(mn); mn.position=Vector3(0,.13,-.04); mn.scale=Vector3(1.0,.78,.72)
    for sx in [-1.0,1.0]:
        var eye:=SphereMesh.new(); eye.radius=.035; eye.height=.07
        var en:=MeshInstance3D.new(); en.mesh=eye; en.material_override=_material(accent,.15,.06,4.5); head_socket.add_child(en); en.position=Vector3(.075*sx,.16,-.205)
    if kind in ["charger","brute"] or boss_mode:
        for sx in [-1.0,1.0]:
            var horn:=CylinderMesh.new(); horn.top_radius=.0; horn.bottom_radius=.065; horn.height=.38 if not boss_mode else .58; horn.radial_segments=7
            var hn:=MeshInstance3D.new(); hn.mesh=horn; hn.material_override=_material(Color(.12,.055,.025),.62,.18); head_socket.add_child(hn); hn.position=Vector3(.17*sx,.33,0); hn.rotation=Vector3(0,0,-.42*sx)

func _build_monster_armor(style: Dictionary) -> void:
    chest_socket=_attachment("MonsterChest","chest")
    var plate:=BoxMesh.new(); plate.size=Vector3(.62,.32,.18)
    var pn:=MeshInstance3D.new(); pn.mesh=plate; pn.material_override=_material(style.armor,.30,.70); chest_socket.add_child(pn); pn.position=Vector3(0,.02,-.22)
    for sx in [-1.0,1.0]:
        var spike:=CylinderMesh.new(); spike.top_radius=.0; spike.bottom_radius=.055; spike.height=.28; spike.radial_segments=6
        var sn:=MeshInstance3D.new(); sn.mesh=spike; sn.material_override=_material(style.armor,.38,.48); chest_socket.add_child(sn); sn.position=Vector3(.32*sx,.18,0); sn.rotation.z=-.65*sx
    if boss_mode:
        cape=MeshInstance3D.new(); cape.mesh=_cloth_panel_mesh(); cape.material_override=_material(primary.darkened(.25),.92,.0); chest_socket.add_child(cape); cape.position=Vector3(0,-.18,.26); cape.scale=Vector3(1.35,1.65,1.0)

func _build_species_details(style: Dictionary) -> void:
    var hand_l:=_attachment("ClawL","hand_l"); var hand_r:=_attachment("ClawR","hand_r")
    var claw_mat:=_material(Color(.15,.06,.04),.42,.30)
    for socket in [hand_l,hand_r]:
        for j in range(3):
            var claw:=CylinderMesh.new(); claw.top_radius=0.0; claw.bottom_radius=.018; claw.height=.16 if kind!="brute" else .22; claw.radial_segments=5
            var cn:=MeshInstance3D.new(); cn.mesh=claw; cn.material_override=claw_mat; socket.add_child(cn); cn.position=Vector3((j-1)*.035,-.13,-.06); cn.rotation_degrees.x=68
    if kind in ["runner","charger"]:
        var spine_socket:=_attachment("BackSpines","chest")
        for j in range(4):
            var sp:=CylinderMesh.new(); sp.top_radius=0.0; sp.bottom_radius=.035; sp.height=.24+.035*j; sp.radial_segments=6
            var sn:=MeshInstance3D.new(); sn.mesh=sp; sn.material_override=_material(style.armor,.45,.42); spine_socket.add_child(sn); sn.position=Vector3(0,.17-.13*j,.16); sn.rotation_degrees.x=-58
    if kind=="brute":
        var chest:=_attachment("BruteArmor","chest")
        for sx in [-1.0,1.0]:
            var pauldron:=SphereMesh.new(); pauldron.radius=.16; pauldron.height=.24
            var pn:=MeshInstance3D.new(); pn.mesh=pauldron; pn.material_override=_material(style.armor,.27,.78); chest.add_child(pn); pn.position=Vector3(.38*sx,.16,0); pn.scale=Vector3(1.25,.75,1.1)
    if kind=="oracle":
        var shroud:=_attachment("OracleShroud","hips")
        var panel:=MeshInstance3D.new(); panel.mesh=_cloth_panel_mesh(); panel.material_override=_material(Color(style.primary.r,style.primary.g,style.primary.b,.86),.88,.0); shroud.add_child(panel); panel.position=Vector3(0,.06,.14); panel.scale=Vector3(1.22,1.28,1.0)
    if boss_mode:
        var crown:=_attachment("BossCrown","head")
        for j in range(7):
            var a:=lerp(-1.0,1.0,float(j)/6.0)
            var horn:=CylinderMesh.new(); horn.top_radius=0.0; horn.bottom_radius=.045; horn.height=.38+.14*(1.0-abs(a)); horn.radial_segments=6
            var hn:=MeshInstance3D.new(); hn.mesh=horn; hn.material_override=_material(Color(.08,.03,.025),.34,.52); crown.add_child(hn); hn.position=Vector3(a*.24,.31,0); hn.rotation.z=-a*.42

func _build_oracle_focus() -> void:
    weapon_socket=_attachment("OracleFocus","hand_r")
    var orb:=SphereMesh.new(); orb.radius=.105; orb.height=.21
    var n:=MeshInstance3D.new(); n.mesh=orb; n.material_override=_material(accent,.15,.12,5.0); weapon_socket.add_child(n); n.position=Vector3(0,-.08,-.03)

func animate_enemy(delta: float, velocity: Vector3, move_speed: float, attack_pose: float, cast_pose: float, hit_pose: float, boss_weight: float = 0.0) -> void:
    # Bone-driven enemy locomotion and combat telegraphing. Heavy enemies deliberately
    # move with a lower gait frequency and larger torso anticipation than runners.
    var speed_ratio := clamp(Vector2(velocity.x, velocity.z).length() / max(.01, move_speed), 0.0, 1.5)
    var weight := 1.0 + (0.55 if kind == "brute" else 0.0) + boss_weight * 0.8
    var cadence := (5.0 + 6.0 * speed_ratio) / weight
    gait_phase += delta * cadence
    idle_phase += delta * (1.35 if boss_mode else 1.8)
    cloth_phase += delta * 2.2

    var gait := sin(gait_phase) * .62 * clamp(speed_ratio, 0.0, 1.0)
    var attack_curve := sin(clamp(attack_pose, 0.0, 1.0) * PI)
    var cast_curve := sin(clamp(cast_pose, 0.0, 1.0) * PI)
    var breathe := sin(idle_phase) * (.025 + boss_weight * .018)
    var shoulder_roll := sin(gait_phase + PI * .5) * .05 * speed_ratio

    # Strong anticipation: chest compresses before melee impact, while casters open up.
    _pose("hips", Vector3(0, gait * .08, 0), delta, 9.0 / weight)
    _pose("spine", Vector3(-.05 * speed_ratio + attack_curve * .13 - hit_pose * .18, shoulder_roll, 0), delta, 10.0 / weight)
    _pose("chest", Vector3(breathe - attack_curve * .23 - cast_curve * .08, -shoulder_roll * .65, 0), delta, 11.0 / weight)
    _pose("neck", Vector3(.035 + attack_curve * .08, 0, 0), delta, 9.0 / weight)
    _pose("head", Vector3(-.025 - hit_pose * .16, cast_curve * .10, 0), delta, 10.0 / weight)

    var melee_swing := attack_curve * (1.15 if kind in ["brute", "charger"] or boss_mode else .92)
    var cast_open := cast_curve * (1.0 if kind == "oracle" or boss_mode else .45)
    _pose("upper_arm_l", Vector3(-gait * .36 - melee_swing * .48 + cast_open * .86, 0, -.18 - cast_open * .28), delta, 13.0 / weight)
    _pose("forearm_l", Vector3(-.12 - melee_swing * .65 - cast_open * .28, 0, .08), delta, 13.0 / weight)
    _pose("hand_l", Vector3(-melee_swing * .14, 0, cast_open * .12), delta, 14.0 / weight)
    _pose("upper_arm_r", Vector3(gait * .36 - melee_swing * 1.12 + cast_open * .72, 0, .18 + cast_open * .30), delta, 14.0 / weight)
    _pose("forearm_r", Vector3(-.14 - melee_swing * .82 - cast_open * .30, 0, -.08), delta, 14.0 / weight)
    _pose("hand_r", Vector3(melee_swing * .16, 0, -cast_open * .12), delta, 14.0 / weight)

    var stride := gait * (.70 if kind == "runner" else .50)
    if kind == "charger": stride *= 1.18
    _pose("thigh_l", Vector3(stride, 0, .03), delta, 11.0 / weight)
    _pose("calf_l", Vector3(max(0.0, -stride) * .66, 0, 0), delta, 11.0 / weight)
    _pose("foot_l", Vector3(-max(0.0, stride) * .24, 0, 0), delta, 12.0 / weight)
    _pose("thigh_r", Vector3(-stride, 0, -.03), delta, 11.0 / weight)
    _pose("calf_r", Vector3(max(0.0, stride) * .66, 0, 0), delta, 11.0 / weight)
    _pose("foot_r", Vector3(-max(0.0, -stride) * .24, 0, 0), delta, 12.0 / weight)

    # Secondary motion keeps capes/shrouds alive without needing a cloth solver.
    if is_instance_valid(cape):
        cape.rotation.x = lerp(cape.rotation.x, -.10 + sin(cloth_phase) * .055 + speed_ratio * .08, 1.0 - exp(-5.0 * delta))
