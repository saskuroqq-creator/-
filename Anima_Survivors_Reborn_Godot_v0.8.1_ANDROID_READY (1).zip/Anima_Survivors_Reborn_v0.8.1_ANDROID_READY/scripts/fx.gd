class_name AnimaFX
extends RefCounted

static func mat(color: Color, emission: float = 0.0, roughness: float = 0.48, metallic: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    if color.a < 0.995:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
    m.roughness = roughness
    m.metallic = metallic
    if emission > 0.0:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = emission
    return m

static func primitive(mesh: PrimitiveMesh, color: Color, emission: float = 0.0, roughness: float = 0.48, metallic: float = 0.0) -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.mesh = mesh
    n.material_override = mat(color, emission, roughness, metallic)
    return n

static func contact_shadow(parent: Node3D, pos: Vector3, radius: float = 0.62, opacity: float = 0.34) -> MeshInstance3D:
    var disk := CylinderMesh.new()
    disk.top_radius = radius
    disk.bottom_radius = radius
    disk.height = 0.008
    disk.radial_segments = 24
    var n := primitive(disk, Color(0.01,0.015,0.02,opacity), 0.0, 1.0, 0.0)
    parent.add_child(n)
    n.global_position = pos + Vector3.UP * 0.012
    return n

static func transient_light(parent: Node3D, pos: Vector3, color: Color, energy: float = 3.0, range_value: float = 4.0, duration: float = 0.12) -> void:
    var l := OmniLight3D.new()
    l.light_color = color
    l.light_energy = energy
    l.omni_range = range_value
    l.shadow_enabled = false
    parent.add_child(l)
    l.global_position = pos
    var tw := parent.create_tween()
    tw.tween_property(l, "light_energy", 0.0, duration).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
    tw.tween_callback(l.queue_free)

static func debris(parent: Node3D, pos: Vector3, color: Color, count: int = 8, force: float = 1.0) -> void:
    var root := Node3D.new()
    parent.add_child(root)
    root.global_position = pos
    var rng := RandomNumberGenerator.new(); rng.randomize()
    for i in range(count):
        var mesh := BoxMesh.new(); mesh.size = Vector3(rng.randf_range(.035,.11),rng.randf_range(.025,.085),rng.randf_range(.05,.16))
        var n := primitive(mesh,color.darkened(rng.randf_range(.02,.28)),0.0,.82,0.02)
        root.add_child(n)
        n.position = Vector3(rng.randf_range(-.16,.16),rng.randf_range(.08,.34),rng.randf_range(-.16,.16))
        n.rotation = Vector3(rng.randf_range(0,PI),rng.randf_range(0,PI),rng.randf_range(0,PI))
        var target := n.position + Vector3(rng.randf_range(-1.0,1.0),rng.randf_range(.45,1.65),rng.randf_range(-1.0,1.0))*force
        var tw := parent.create_tween(); tw.set_parallel(true)
        tw.tween_property(n,"position",target,.28).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
        tw.tween_property(n,"rotation",n.rotation+Vector3(rng.randf_range(1,4),rng.randf_range(1,4),rng.randf_range(1,4)),.32)
        tw.tween_property(n,"scale",Vector3.ONE*.04,.38).set_delay(.10)
        tw.chain().tween_callback(n.queue_free)
    parent.get_tree().create_timer(.55).timeout.connect(root.queue_free)

static func flash(parent: Node3D, pos: Vector3, color: Color, size: float = 1.0) -> void:
    var sphere := SphereMesh.new()
    sphere.radius = 0.22; sphere.height = 0.44
    var n := primitive(sphere, color, 7.0)
    parent.add_child(n); n.global_position = pos; n.scale = Vector3.ONE * 0.05
    var tw := parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(n, "scale", Vector3.ONE * size * 2.6, 0.14).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tw.tween_property(n, "transparency", 1.0, 0.16)
    tw.chain().tween_callback(n.queue_free)

static func ring(parent: Node3D, pos: Vector3, color: Color, radius: float = 5.0, duration: float = 0.35) -> void:
    var torus := TorusMesh.new(); torus.inner_radius = 0.88; torus.outer_radius = 1.0; torus.rings = 32; torus.ring_segments = 10
    var n := primitive(torus, color, 5.0)
    parent.add_child(n); n.global_position = pos + Vector3(0, 0.08, 0); n.rotation_degrees.x = 90.0; n.scale = Vector3.ONE * 0.12
    var tw := parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(n, "scale", Vector3.ONE * radius, duration).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tw.tween_property(n, "transparency", 1.0, duration)
    tw.chain().tween_callback(n.queue_free)

static func slash(parent: Node3D, pos: Vector3, direction: Vector3, color: Color, reach: float = 2.6) -> void:
    var box := BoxMesh.new(); box.size = Vector3(0.10, 0.055, reach)
    var n := primitive(box, color, 8.0)
    parent.add_child(n); n.global_position = pos + Vector3(0, 0.82, 0) + direction * reach * 0.45
    if direction.length_squared() > 0.001: n.look_at(n.global_position + direction, Vector3.UP)
    n.scale = Vector3(0.1, 0.1, 0.28)
    var tw := parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(n, "scale", Vector3(2.3, 1.0, 1.0), 0.11).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tw.tween_property(n, "transparency", 1.0, 0.19)
    tw.chain().tween_callback(n.queue_free)
    sparks(parent, pos + Vector3.UP * 0.8 + direction * reach * 0.55, color, 10, 0.55)
    transient_light(parent,pos+Vector3.UP*.8+direction*reach*.35,color,2.8,3.2,.10)

static func sparks(parent: Node3D, pos: Vector3, color: Color, count: int = 14, speed: float = 1.0) -> void:
    var p := GPUParticles3D.new(); p.amount = count; p.lifetime = 0.42; p.one_shot = true; p.explosiveness = 1.0
    var pm := ParticleProcessMaterial.new(); pm.direction = Vector3(0, 0.45, 1); pm.spread = 180.0
    pm.initial_velocity_min = 3.0 * speed; pm.initial_velocity_max = 7.0 * speed; pm.gravity = Vector3(0, -8.5, 0)
    pm.scale_min = 0.45; pm.scale_max = 1.25; pm.color = color
    p.process_material = pm
    var mesh := QuadMesh.new(); mesh.size = Vector2(0.075, 0.22); mesh.material = mat(color, 8.0, 0.2)
    p.draw_pass_1 = mesh
    parent.add_child(p); p.global_position = pos; p.emitting = true
    parent.get_tree().create_timer(0.75).timeout.connect(p.queue_free)

static func dust(parent: Node3D, pos: Vector3, color: Color = Color(0.75,0.72,0.68)) -> void:
    var p := GPUParticles3D.new(); p.amount = 10; p.lifetime = 0.55; p.one_shot = true; p.explosiveness = 1.0
    var pm := ParticleProcessMaterial.new(); pm.direction = Vector3.UP; pm.spread = 75.0; pm.initial_velocity_min = 0.8; pm.initial_velocity_max = 2.0
    pm.gravity = Vector3(0,-1.2,0); pm.scale_min = 0.7; pm.scale_max = 1.5; pm.color = Color(color.r,color.g,color.b,0.48)
    p.process_material = pm
    var mesh := SphereMesh.new(); mesh.radius = 0.065; mesh.height = 0.13; mesh.material = mat(Color(color.r,color.g,color.b,0.4),0.0,1.0)
    p.draw_pass_1 = mesh; parent.add_child(p); p.global_position = pos + Vector3.UP*0.08; p.emitting = true
    parent.get_tree().create_timer(0.9).timeout.connect(p.queue_free)

static func afterimage(parent: Node3D, pos: Vector3, color: Color, direction: Vector3) -> void:
    var cap := CapsuleMesh.new(); cap.radius = 0.34; cap.height = 1.2
    var n := primitive(cap, Color(color.r,color.g,color.b,0.34), 2.5)
    parent.add_child(n); n.global_position = pos + Vector3.UP*0.72 - direction*0.22
    var tw := parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(n,"scale",Vector3(0.72,1.15,0.72),0.18)
    tw.tween_property(n,"transparency",1.0,0.22)
    tw.chain().tween_callback(n.queue_free)

static func lightning(parent: Node3D, a: Vector3, b: Vector3, color: Color) -> void:
    var root := Node3D.new(); parent.add_child(root)
    var last := a; var rng := RandomNumberGenerator.new(); rng.randomize()
    for i in range(1, 10):
        var t := float(i) / 9.0; var point := a.lerp(b, t)
        if i < 9: point += Vector3(rng.randf_range(-0.32,0.32),rng.randf_range(-0.12,0.38),rng.randf_range(-0.32,0.32))
        var seg := CylinderMesh.new(); seg.top_radius = 0.026; seg.bottom_radius = 0.055; seg.height = max(0.05,last.distance_to(point)); seg.radial_segments = 6
        var m := primitive(seg,color,10.0); root.add_child(m); m.global_position = (last+point)*0.5; m.look_at(point,Vector3.FORWARD); m.rotate_object_local(Vector3.RIGHT,PI*0.5); last = point
    flash(parent,b,color,0.65); sparks(parent,b,color,16,0.85); transient_light(parent,b,color,5.2,5.0,.12)
    var tw := parent.create_tween(); tw.tween_interval(0.085); tw.tween_callback(root.queue_free)

static func damage_number(parent: Node3D, pos: Vector3, value: int, crit: bool = false) -> void:
    var label := Label3D.new(); label.text = ("✦ " if crit else "") + str(value); label.font_size = 38 if crit else 27
    label.modulate = Color(1.0,0.76,0.18) if crit else Color(0.95,0.98,1.0); label.outline_size = 7; label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    parent.add_child(label); label.global_position = pos + Vector3(0,1.55,0)
    var tw := parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(label,"position:y",label.position.y+1.25,0.52).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tw.tween_property(label,"modulate:a",0.0,0.55); tw.tween_property(label,"scale",Vector3.ONE*(1.18 if crit else 1.0),0.18)
    tw.chain().tween_callback(label.queue_free)

static func speed_lines(parent: Node3D, pos: Vector3, direction: Vector3, color: Color, count: int = 10) -> void:
    var root := Node3D.new()
    parent.add_child(root)
    root.global_position = pos
    var rng := RandomNumberGenerator.new(); rng.randomize()
    for i in range(count):
        var mesh := BoxMesh.new(); mesh.size = Vector3(.025,.025,rng.randf_range(.55,1.25))
        var n := primitive(mesh,Color(color.r,color.g,color.b,.55),5.0)
        root.add_child(n)
        var side := Vector3(-direction.z,0,direction.x)
        n.position = -direction*rng.randf_range(.2,1.9) + side*rng.randf_range(-.75,.75) + Vector3.UP*rng.randf_range(-.45,.45)
        if direction.length_squared()>.001:
            n.look_at(n.global_position + direction,Vector3.UP)
    var tw := parent.create_tween()
    tw.tween_property(root,"scale",Vector3(1,1,2.1),.16).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tw.tween_callback(root.queue_free)

static func projectile_trail(parent: Node3D, pos: Vector3, color: Color, scale: float = 1.0) -> void:
    var sphere:=SphereMesh.new(); sphere.radius=.075*scale; sphere.height=.15*scale
    var n:=primitive(sphere,Color(color.r,color.g,color.b,.42),4.5)
    parent.add_child(n); n.global_position=pos
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(n,"scale",Vector3.ONE*.18,.18)
    tw.tween_property(n,"transparency",1.0,.20)
    tw.chain().tween_callback(n.queue_free)

static func impact(parent: Node3D, pos: Vector3, color: Color, power: float = 1.0) -> void:
    flash(parent,pos,color,.55*power)
    ring(parent,pos-Vector3.UP*.65,color,.55*power,.14)
    sparks(parent,pos,color,int(10+8*power),.55+.25*power)
    transient_light(parent,pos,color,2.2+power*2.3,2.6+power*2.2,.11+.035*power)
    if power >= .72:
        debris(parent,pos-Vector3.UP*.55,color.darkened(.35),int(5+power*5),.34+power*.22)

static func steel_impact(parent: Node3D, pos: Vector3, direction: Vector3, power: float = 1.0) -> void:
    var hot := Color(1.0,.82,.46)
    sparks(parent,pos,hot,int(14+power*12),.8+power*.28)
    transient_light(parent,pos,hot,3.8+power*2.0,3.2+power*1.5,.09)
    var mesh:=BoxMesh.new(); mesh.size=Vector3(.035,.025,.72+power*.4)
    var n:=primitive(mesh,Color(1.0,.92,.7,.76),9.0,.16,.72); parent.add_child(n); n.global_position=pos
    var d:=direction.normalized() if direction.length_squared()>.001 else Vector3.FORWARD
    n.look_at(pos+d,Vector3.UP)
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(n,"scale",Vector3(.12,.12,1.8),.08)
    tw.tween_property(n,"transparency",1.0,.13)
    tw.chain().tween_callback(n.queue_free)

static func magic_impact(parent: Node3D, pos: Vector3, color: Color, power: float = 1.0) -> void:
    flash(parent,pos,color,.68*power)
    ring(parent,pos-Vector3.UP*.58,color,.72*power,.18)
    rune_circle(parent,pos-Vector3.UP*.64,Color(color.r,color.g,color.b,.72),.7+power*.45,.22)
    transient_light(parent,pos,color,4.0+power*2.2,4.0+power*2.0,.16)
    sparks(parent,pos,color,int(9+power*9),.42+power*.18)

static func weapon_muzzle(parent: Node3D, pos: Vector3, direction: Vector3, color: Color, scale: float = 1.0) -> void:
    flash(parent,pos,color,.42*scale)
    sparks(parent,pos,color,12,0.55*scale)
    var cone:=CylinderMesh.new(); cone.top_radius=.015; cone.bottom_radius=.16*scale; cone.height=.8*scale; cone.radial_segments=10
    var n:=primitive(cone,Color(color.r,color.g,color.b,.72),8.0)
    parent.add_child(n); n.global_position=pos+direction.normalized()*.32*scale
    if direction.length_squared()>.001:
        n.look_at(n.global_position+direction,Vector3.UP); n.rotate_object_local(Vector3.RIGHT,PI*.5)
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(n,"scale",Vector3(.22,.22,1.7),.09).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tw.tween_property(n,"transparency",1.0,.13)
    tw.chain().tween_callback(n.queue_free)

static func arc_sweep(parent: Node3D, pos: Vector3, direction: Vector3, color: Color, radius: float = 2.8, arc: float = 1.9, width: float = .08) -> void:
    var root:=Node3D.new(); parent.add_child(root); root.global_position=pos+Vector3.UP*.82
    var base:=direction.normalized()
    if base.length_squared()<.001: base=Vector3.FORWARD
    var steps:=11
    var prev:=base.rotated(Vector3.UP,-arc*.5)*radius
    for i in range(1,steps+1):
        var t=float(i)/float(steps)
        var cur:=base.rotated(Vector3.UP,-arc*.5+arc*t)*radius
        var mid=(prev+cur)*.5
        var d=cur-prev
        var seg:=BoxMesh.new(); seg.size=Vector3(width,.035,max(.04,d.length()))
        var n:=primitive(seg,Color(color.r,color.g,color.b,.78),10.0); root.add_child(n); n.position=mid
        if d.length_squared()>.001: n.look_at(root.global_position+cur,Vector3.UP)
        prev=cur
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(root,"scale",Vector3(1.15,1.0,1.15),.14).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    for c in root.get_children(): tw.tween_property(c,"transparency",1.0,.20)
    tw.chain().tween_callback(root.queue_free)

static func blade_orbit_trail(parent: Node3D, pos: Vector3, color: Color, tangent: Vector3) -> void:
    var mesh:=BoxMesh.new(); mesh.size=Vector3(.035,.025,.58)
    var n:=primitive(mesh,Color(color.r,color.g,color.b,.34),5.5); parent.add_child(n); n.global_position=pos
    if tangent.length_squared()>.001: n.look_at(pos+tangent,Vector3.UP)
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(n,"scale",Vector3(.4,.4,1.55),.12)
    tw.tween_property(n,"transparency",1.0,.16)
    tw.chain().tween_callback(n.queue_free)

static func whip_arc(parent: Node3D, pos: Vector3, direction: Vector3, color: Color, reach: float = 4.0) -> void:
    arc_sweep(parent,pos,direction,color,reach*.82,2.25,.10)
    arc_sweep(parent,pos+Vector3.UP*.06,direction,Color(1.0,.74,.24,.62),reach*.68,1.75,.045)
    sparks(parent,pos+Vector3.UP*.82+direction.normalized()*reach*.74,color,20,.85)
    ring(parent,pos+direction.normalized()*reach*.62,color,.72,.13)

static func rune_circle(parent: Node3D, pos: Vector3, color: Color, radius: float = 3.4, duration: float = .45) -> void:
    ring(parent,pos,color,radius,duration)
    ring(parent,pos,Color(color.r,color.g,color.b,.48),radius*.62,duration*.9)
    var root:=Node3D.new(); parent.add_child(root); root.global_position=pos+Vector3.UP*.055
    for i in range(8):
        var a=TAU*float(i)/8.0
        var bar:=BoxMesh.new(); bar.size=Vector3(.045,.025,.55)
        var n:=primitive(bar,Color(color.r,color.g,color.b,.72),6.0); root.add_child(n)
        n.position=Vector3(cos(a)*radius*.80,0,sin(a)*radius*.80); n.rotation.y=-a
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(root,"rotation:y",PI*.38,duration)
    tw.tween_property(root,"scale",Vector3.ONE*1.08,duration)
    for c in root.get_children(): tw.tween_property(c,"transparency",1.0,duration)
    tw.chain().tween_callback(root.queue_free)

static func aura_burst(parent: Node3D, pos: Vector3, color: Color, radius: float = 3.0) -> void:
    flash(parent,pos+Vector3.UP*.8,color,.9)
    ring(parent,pos,color,radius,.28)
    var p:=GPUParticles3D.new(); p.amount=34; p.lifetime=.64; p.one_shot=true; p.explosiveness=1.0
    var pm:=ParticleProcessMaterial.new(); pm.direction=Vector3.UP; pm.spread=180.0; pm.initial_velocity_min=2.2; pm.initial_velocity_max=6.4
    pm.gravity=Vector3(0,-2.4,0); pm.scale_min=.5; pm.scale_max=1.4; pm.color=color
    p.process_material=pm
    var q:=QuadMesh.new(); q.size=Vector2(.055,.28); q.material=mat(color,8.0,.18)
    p.draw_pass_1=q; parent.add_child(p); p.global_position=pos+Vector3.UP*.5; p.emitting=true
    parent.get_tree().create_timer(.9).timeout.connect(p.queue_free)

static func blade_storm(parent: Node3D, pos: Vector3, color: Color, radius: float = 7.0) -> void:
    rune_circle(parent,pos,color,radius*.55,.52)
    for i in range(12):
        var a=TAU*float(i)/12.0
        var d=Vector3(cos(a),0,sin(a))
        arc_sweep(parent,pos+d*radius*.18,d,color,radius*.36,1.25,.065)
    aura_burst(parent,pos,color,radius*.72)

static func void_bloom(parent: Node3D, pos: Vector3, color: Color, radius: float = 5.0) -> void:
    rune_circle(parent,pos,color,radius*.72,.48)
    var root:=Node3D.new(); parent.add_child(root); root.global_position=pos+Vector3.UP*.9
    for i in range(10):
        var a=TAU*float(i)/10.0
        var mesh:=SphereMesh.new(); mesh.radius=.10; mesh.height=.20
        var n:=primitive(mesh,color,9.0); root.add_child(n); n.position=Vector3(cos(a)*.7,sin(a*2.0)*.18,sin(a)*.7)
        var tw:=parent.create_tween(); tw.set_parallel(true)
        tw.tween_property(n,"position",Vector3(cos(a)*radius,randf_range(-.25,.9),sin(a)*radius),.24).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
        tw.tween_property(n,"transparency",1.0,.34)
    parent.get_tree().create_timer(.42).timeout.connect(root.queue_free)

static func eclipse(parent: Node3D, pos: Vector3, color: Color, radius: float = 8.0) -> void:
    rune_circle(parent,pos,color,radius*.62,.7)
    var sphere:=SphereMesh.new(); sphere.radius=.7; sphere.height=1.4
    var core:=primitive(sphere,Color(.08,.035,.16,.82),4.0); parent.add_child(core); core.global_position=pos+Vector3.UP*3.2; core.scale=Vector3.ONE*.12
    var light:=OmniLight3D.new(); light.light_color=color; light.light_energy=4.0; light.omni_range=10.0; core.add_child(light)
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(core,"scale",Vector3.ONE*2.2,.34).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_property(core,"position:y",core.position.y+.55,.55)
    tw.chain().tween_property(core,"transparency",1.0,.28)
    tw.chain().tween_callback(core.queue_free)
    aura_burst(parent,pos,color,radius*.72)

static func crimson_cyclone(parent: Node3D, pos: Vector3, color: Color, radius: float = 6.0) -> void:
    rune_circle(parent,pos,color,radius*.48,.5)
    for i in range(8):
        var a=TAU*float(i)/8.0
        var d=Vector3(cos(a),0,sin(a))
        arc_sweep(parent,pos+Vector3.UP*(.12+.08*i),d,color,radius*(.32+.018*i),1.72,.075)
    aura_burst(parent,pos,color,radius*.62)

static func owl_launch(parent: Node3D, pos: Vector3, direction: Vector3, color: Color) -> void:
    var root:=Node3D.new(); parent.add_child(root); root.global_position=pos
    for side in [-1.0,1.0]:
        var wing:=BoxMesh.new(); wing.size=Vector3(.36,.035,.16)
        var n:=primitive(wing,Color(color.r,color.g,color.b,.75),6.0); root.add_child(n); n.position=Vector3(side*.19,0,0); n.rotation.z=side*.28
    var core:=SphereMesh.new(); core.radius=.085; core.height=.17
    var c:=primitive(core,color,9.0); root.add_child(c)
    if direction.length_squared()>.001: root.look_at(pos+direction,Vector3.UP)
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(root,"scale",Vector3.ONE*1.45,.10)
    for ch in root.get_children(): tw.tween_property(ch,"transparency",1.0,.16)
    tw.chain().tween_callback(root.queue_free)

static func thunder_sigil(parent: Node3D, pos: Vector3, color: Color, radius: float = 2.2) -> void:
    rune_circle(parent,pos,color,radius,.24)
    var root:=Node3D.new(); parent.add_child(root); root.global_position=pos+Vector3.UP*.08
    for i in range(6):
        var a=TAU*float(i)/6.0
        var mesh:=BoxMesh.new(); mesh.size=Vector3(.05,.025,radius*.6)
        var n:=primitive(mesh,color,8.0); root.add_child(n); n.position=Vector3(cos(a)*radius*.55,0,sin(a)*radius*.55); n.rotation.y=-a
    var tw:=parent.create_tween(); tw.set_parallel(true)
    tw.tween_property(root,"rotation:y",PI*.8,.18)
    for c in root.get_children(): tw.tween_property(c,"transparency",1.0,.22)
    tw.chain().tween_callback(root.queue_free)

static func trail_styled(parent: Node3D, pos: Vector3, color: Color, style: String, direction: Vector3 = Vector3.FORWARD) -> void:
    match style:
        "shard", "void":
            var mesh:=BoxMesh.new(); mesh.size=Vector3(.04,.04,.48 if style=="shard" else .72)
            var n:=primitive(mesh,Color(color.r,color.g,color.b,.38),7.0); parent.add_child(n); n.global_position=pos
            if direction.length_squared()>.001: n.look_at(pos+direction,Vector3.UP)
            var tw:=parent.create_tween(); tw.set_parallel(true); tw.tween_property(n,"scale",Vector3(.25,.25,1.55),.14); tw.tween_property(n,"transparency",1.0,.18); tw.chain().tween_callback(n.queue_free)
        "owl":
            projectile_trail(parent,pos,Color(color.r,color.g,color.b,.46),1.25)
            if randf()<.28: sparks(parent,pos,color,3,.22)
        _:
            projectile_trail(parent,pos,color,.82)
