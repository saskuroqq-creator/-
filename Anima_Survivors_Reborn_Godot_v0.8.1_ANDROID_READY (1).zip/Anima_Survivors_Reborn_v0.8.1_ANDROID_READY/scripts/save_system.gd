extends Node

const SAVE_PATH := "user://anima_reborn.save"
var data := {
    "coins": 0,
    "runs": 0,
    "best_time": 0.0,
    "best_kills": 0,
    "best_wave": 0,
    "meta": {"power":0,"vitality":0,"haste":0,"fortune":0},
    "achievements": {}
}

func _ready() -> void:
    load_save()

func load_save() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if f == null:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    if typeof(parsed) == TYPE_DICTIONARY:
        _merge(data, parsed)

func save() -> void:
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data))

func _merge(dst: Dictionary, src: Dictionary) -> void:
    for k in src:
        if dst.has(k) and typeof(dst[k]) == TYPE_DICTIONARY and typeof(src[k]) == TYPE_DICTIONARY:
            _merge(dst[k], src[k])
        else:
            dst[k] = src[k]

func add_coins(amount: int) -> void:
    data.coins = int(data.coins) + amount
    save()

func meta_level(id: String) -> int:
    return int(data.meta.get(id,0))

func meta_cost(id: String) -> int:
    var lv := meta_level(id)
    return 40 + lv * 35 + lv * lv * 10

func buy_meta(id: String) -> bool:
    var cost := meta_cost(id)
    if int(data.coins) < cost or meta_level(id) >= 10:
        return false
    data.coins = int(data.coins) - cost
    data.meta[id] = meta_level(id) + 1
    save()
    return true

func unlock(id: String, reward: int) -> bool:
    if bool(data.achievements.get(id,false)):
        return false
    data.achievements[id] = true
    data.coins = int(data.coins) + reward
    save()
    return true

func finish_run(time: float, kills: int, wave: int) -> void:
    data.runs = int(data.runs)+1
    data.best_time = max(float(data.best_time), time)
    data.best_kills = max(int(data.best_kills), kills)
    data.best_wave = max(int(data.best_wave), wave)
    save()
