class_name AnimaPlayer
extends CharacterBody3D

signal health_changed(current, maximum)
signal xp_changed(current, needed, level)
signal died
signal dash_changed(value)
signal anima_changed(value, maximum)

var hero_id := "sakura"
var hp := 100.0
var max_hp := 100.0
var move_speed := 7.5
var accel := 28.0
var decel := 34.0
var damage_mult := 1.0
var cooldown_mult := 1.0
var crit_chance := 0.08
var pickup_radius := 7.5
var level := 1
var xp := 0
var xp_need := 10
var iframe := 0.0
var dash_cd := 0.0
var dash_duration := 0.0
var dash_dir := Vector3.ZERO
var dash_speed := 20.0
var last_dir := Vector3.FORWARD
var knockback := Vector3.ZERO
var visual: Node3D
var camera: Camera3D
var camera_velocity := Vector3.ZERO
var camera_shake := 0.0
var dash_ghost_clock := 0.0
var accent_color := Color(0.35,0.95,1.0)
var weapon_anchor: Node3D
var bob_t := 0.0
var hit_stun := 0.0
var left_arm_pivot: Node3D
var right_arm_pivot: Node3D
var left_leg_pivot: Node3D
var right_leg_pivot: Node3D
var weapon_pivot: Node3D
var weapon_model: MeshInstance3D
var gait_phase := 0.0
var weapon_kick := 0.0
var dash_fov_boost := 0.0
var shield_charges := 0
var temporary_damage_bonus := 0.0
var temporary_damage_time := 0.0
var mobile_vector := Vector2.ZERO
var upgrades := {"blade":1,"shard":0,"ring":0,"whip":0,"owls":0,"thunder":0,"fury":0,"haste":0,"vitality":0,"magnet":0}
var weapon_timers := {"shard":0.0,"ring":0.0,"whip":0.0,"owls":0.0,"thunder":0.0}
var blade_angle := 0.0
var blade_nodes: Array[MeshInstance3D] = []
var blade_hit_cd := {}
var torso_node: MeshInstance3D
var coat_node: MeshInstance3D
var head_node: MeshInstance3D
var sash_node: MeshInstance3D
var idle_phase := 0.0
var footstep_phase := 0.0
var attack_pose := 0.0
var cast_pose := 0.0
var hit_pose := 0.0
var attack_style := ""
var anima_charge := 0.0
var anima_max := 100.0
var blade_trail_clock := 0.0
var contact_shadow: MeshInstance3D
var previous_velocity := Vector3.ZERO
var acceleration_impulse := Vector3.ZERO
var turn_bank := 0.0
var production_rig: AnimaCharacterRig
var external_visual_state := {}

const HEROES := {
    "sakura":{"hp":110.0,"speed":7.6,"color":Color(1.0,0.35,0.68),"accent":Color(0.35,0.95,1.0),"weapon":"blade"},
    "kaito":{"hp":88.0,"speed":8.5,"color":Color(0.26,0.45,0.95),"accent":Color(1.0,0.28,0.72),"weapon":"shard"},
    "luna":{"hp":135.0,"speed":6.8,"color":Color(0.46,0.30,0.86),"accent":Color(1.0,0.82,0.28),"weapon":"ring"},
    "ren":{"hp":102.0,"speed":8.0,"color":Color(0.66,0.20,0.17),"accent":Color(1.0,0.62,0.25),"weapon":"whip"}
}

func setup(id: String) -> void:
    hero_id=id
    var h=HEROES.get(id,HEROES.sakura)
    max_hp=h.hp * (1.0 + SaveSystem.meta_level("vitality")*0.05); hp=max_hp; move_speed=h.speed
    damage_mult *= 1.0 + SaveSystem.meta_level("power")*0.04
    cooldown_mult *= 1.0 - min(0.25,SaveSystem.meta_level("haste")*0.025)
    crit_chance += SaveSystem.meta_level("fortune")*0.012
    upgrades[h.weapon]=1
    collision_layer=2; collision_mask=1|4
    accent_color = h.accent
    _build_visual(h.color,h.accent)
    health_changed.emit(hp,max_hp); xp_changed.emit(xp,xp_need,level); anima_changed.emit(anima_charge,anima_max)

func _make_limb(parent: Node3D, size: Vector3, color: Color, local_pos: Vector3) -> MeshInstance3D:
    var mesh := BoxMesh.new()
    mesh.size = size
    var limb := AnimaFX.primitive(mesh, color, 0.0)
    parent.add_child(limb)
    limb.position = local_pos
    return limb

func _build_visual(color: Color, accent: Color) -> void:
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius=.39; cap.height=1.72; cs.shape=cap; cs.position.y=.84; add_child(cs)

    production_rig=AnimaCharacterRig.new()
    production_rig.name="HeroProductionModel"
    add_child(production_rig)
    production_rig.build(hero_id)
    external_visual_state=AnimaAssetFusion.attach_hero(production_rig,hero_id,production_rig)
    visual=production_rig
    contact_shadow=AnimaFX.contact_shadow(get_parent(),global_position,.55,.28)

    var aura:=OmniLight3D.new(); aura.light_color=accent; aura.light_energy=.55; aura.omni_range=2.8
    production_rig.add_child(aura); aura.position=Vector3(0,1.0,0)

    weapon_anchor=Node3D.new(); add_child(weapon_anchor); weapon_anchor.position.y=.65
    _sync_blades()

    camera=Camera3D.new(); camera.name="CombatCamera"; get_tree().current_scene.add_child(camera)
    camera.global_position=global_position+Vector3(0,11.7,11.7); camera.rotation_degrees=Vector3(-43,0,0); camera.fov=51.5; camera.current=true

func _physics_process(delta: float) -> void:
    iframe=max(0.0,iframe-delta); dash_cd=max(0.0,dash_cd-delta); hit_stun=max(0.0,hit_stun-delta)
    temporary_damage_time=max(0.0,temporary_damage_time-delta)
    if temporary_damage_time<=0.0:
        temporary_damage_bonus=0.0
    dash_changed.emit(dash_cd)
    var input2:=Input.get_vector("move_left","move_right","move_up","move_down")
    if mobile_vector.length()>.05:
        input2=mobile_vector
    var desired:=Vector3(input2.x,0,input2.y)
    if Input.is_action_just_pressed("dash"):
        try_dash(desired)
    if Input.is_action_just_pressed("ability"):
        use_anima_burst()
    if dash_duration>0:
        dash_duration-=delta; velocity=dash_dir*dash_speed
        dash_ghost_clock -= delta
        if dash_ghost_clock <= 0.0:
            dash_ghost_clock = 0.035
            AnimaFX.afterimage(get_parent(),global_position,accent_color,dash_dir)
    elif hit_stun>0:
        velocity=knockback
    else:
        var target:=desired.normalized()*move_speed
        var rate:=accel if desired.length()>.05 else decel
        velocity.x=move_toward(velocity.x,target.x,rate*delta)
        velocity.z=move_toward(velocity.z,target.z,rate*delta)
        velocity.y=0
        if desired.length()>.1:
            last_dir=desired.normalized()
            var target_yaw=atan2(last_dir.x,last_dir.z)
            visual.rotation.y=lerp_angle(visual.rotation.y,target_yaw,delta*11.0)
    knockback=knockback.move_toward(Vector3.ZERO,18*delta)
    move_and_slide()
    acceleration_impulse = (velocity-previous_velocity)/max(delta,.0001)
    previous_velocity = velocity
    if is_instance_valid(contact_shadow):
        contact_shadow.global_position = Vector3(global_position.x,.014,global_position.z)
        var sh_scale:=1.0-clamp(abs(visual.position.y)*.45,0.0,.18)
        contact_shadow.scale=Vector3(sh_scale,1.0,sh_scale)
        contact_shadow.visible=iframe<.98 or dash_duration<=0.0
    var moving := desired.length()>.1
    var speed_ratio := clamp(Vector2(velocity.x,velocity.z).length()/max(0.01,move_speed),0.0,1.6)
    _update_animation(delta,moving,speed_ratio)
    _update_camera(delta)
    _update_weapons(delta)

func _trigger_attack(style: String, strength: float = 1.0) -> void:
    AnimaAudio.play_sfx("slash",.55,.92,1.08)
    attack_style = style
    attack_pose = max(attack_pose, strength)
    weapon_kick = max(weapon_kick, .18 * strength)

func _trigger_cast(style: String, strength: float = 1.0) -> void:
    AnimaAudio.play_sfx("magic",.42,.94,1.06)
    attack_style = style
    cast_pose = max(cast_pose, strength)

func _update_animation(delta: float, moving: bool, speed_ratio: float) -> void:
    idle_phase += delta * (2.25 if not moving else 4.0)
    gait_phase += delta * (4.5 + 8.5*speed_ratio)
    attack_pose = move_toward(attack_pose,0.0,delta*4.9)
    cast_pose = move_toward(cast_pose,0.0,delta*3.6)
    hit_pose = move_toward(hit_pose,0.0,delta*8.0)
    weapon_kick = move_toward(weapon_kick,0.0,delta*6.2)
    var dash_weight := clamp(dash_duration/.18,0.0,1.0)
    var lateral_accel:=acceleration_impulse.x
    turn_bank = lerp(turn_bank,clamp(-lateral_accel*.0075,-.16,.16),1.0-exp(-7.5*delta))
    if is_instance_valid(production_rig):
        production_rig.animate_player(delta,velocity,move_speed,dash_weight,attack_pose,cast_pose,hit_pose,attack_style,acceleration_impulse,turn_bank)
        AnimaAnimationFusion.update_hero(external_visual_state,velocity,move_speed,dash_weight,attack_pose,cast_pose,hit_pose,attack_style)
        var blink_weight:=clamp((sin(idle_phase*1.71)-.965)*28.0,0.0,1.0)
        AnimaAnimationFusion.update_face(external_visual_state,blink_weight,max(attack_pose,cast_pose))
        var lean_x:=velocity.z*.010-dash_weight*.12+hit_pose*.05
        var lean_z:=-velocity.x*.014+turn_bank+hit_pose*.08
        production_rig.rotation.x=lerp(production_rig.rotation.x,lean_x,1.0-exp(-9.0*delta))
        production_rig.rotation.z=lerp(production_rig.rotation.z,lean_z,1.0-exp(-10.0*delta))

    footstep_phase += delta*(4.5+8.5*speed_ratio)
    if moving and footstep_phase>=PI:
        footstep_phase-=PI
        AnimaFX.dust(get_parent(),global_position,Color(0.55,0.5,0.44))
        if speed_ratio>.72: AnimaFX.debris(get_parent(),global_position+Vector3.UP*.04,Color(.28,.25,.22),2,.14)

func _update_camera(delta: float) -> void:
    if not is_instance_valid(camera):
        return
    camera_shake = max(0.0,camera_shake-delta*2.35)
    dash_fov_boost = move_toward(dash_fov_boost,0.0,delta*8.0)
    var speed_ratio := clamp(Vector2(velocity.x,velocity.z).length()/max(0.01,move_speed),0.0,1.7)
    var lead := last_dir * (1.0 + speed_ratio*.55)
    var desired_pos := global_position + Vector3(0,11.6,11.6) + lead
    var stiffness := 18.0
    camera_velocity += (desired_pos-camera.global_position) * stiffness * delta
    camera_velocity *= exp(-7.5*delta)
    camera.global_position += camera_velocity * delta
    camera.fov = lerp(camera.fov,51.5 + speed_ratio*1.6 + dash_fov_boost,1.0-exp(-6.0*delta))
    if camera_shake > 0.0:
        camera.global_position += Vector3(randf_range(-1,1),randf_range(-.42,.42),randf_range(-1,1))*camera_shake
    camera.look_at(global_position+Vector3.UP*.62+lead*.25,Vector3.UP)
    camera.rotation.z = lerp(camera.rotation.z,turn_bank*.06,1.0-exp(-4.5*delta))

func try_dash(dir: Vector3=Vector3.ZERO) -> void:
    if dash_cd>0:
        return
    if dir.length()<.1:
        dir=last_dir
    dash_dir=dir.normalized(); dash_duration=.18; dash_cd=1.45 if hero_id!="ren" else 1.15; iframe=.30; dash_ghost_clock=0.0
    camera_shake=max(camera_shake,0.18); dash_fov_boost=4.2; weapon_kick=.35
    AnimaAudio.play_sfx("dash",.62,.96,1.05)
    if OS.get_name()=="Android" or DisplayServer.is_touchscreen_available(): Input.vibrate_handheld(20)
    AnimaFX.ring(get_parent(),global_position,accent_color,1.25,.18)
    AnimaFX.sparks(get_parent(),global_position+Vector3.UP*.35,accent_color,18,0.78)
    AnimaFX.transient_light(get_parent(),global_position+Vector3.UP*.75,accent_color,4.2,4.8,.13)
    AnimaFX.speed_lines(get_parent(),global_position+Vector3.UP*.75,dash_dir,accent_color,10)

func take_hit(amount: float, from_dir: Vector3) -> void:
    if iframe>0:
        return
    if shield_charges>0:
        shield_charges-=1; iframe=.7; AnimaFX.ring(get_parent(),global_position,Color(.65,.72,1),1.9,.3); return
    var reduction=.1 if hero_id=="luna" else 0.0
    hp-=amount*(1.0-reduction); iframe=.55; hit_stun=.12; hit_pose=1.0; knockback=from_dir*5.0; camera_shake=max(camera_shake,0.35)
    health_changed.emit(hp,max_hp)
    AnimaAudio.play_sfx("hit",.62,.92,1.05)
    var scene:=get_tree().current_scene
    if scene and scene.has_method("player_damage_feedback"): scene.player_damage_feedback(amount/max(1.0,max_hp)*5.0)
    AnimaFX.flash(get_parent(),global_position+Vector3.UP,Color(1,.15,.15),.8)
    AnimaFX.debris(get_parent(),global_position+Vector3.UP*.35,Color(.20,.12,.12),5,.24)
    if hp<=0:
        died.emit()

func heal(amount: float) -> void:
    hp=min(max_hp,hp+amount); health_changed.emit(hp,max_hp)

func gain_xp(v: int) -> void:
    xp+=v
    while xp>=xp_need:
        xp-=xp_need; level+=1; xp_need=int(10+level*4.5+pow(level,1.35)); get_tree().current_scene.call_deferred("request_level_up")
    xp_changed.emit(xp,xp_need,level)

func apply_upgrade(id: String) -> void:
    upgrades[id]=int(upgrades.get(id,0))+1
    if id=="fury":
        damage_mult*=1.12
    if id=="haste":
        cooldown_mult*=.91
    if id=="vitality":
        max_hp+=18
        hp+=18
        health_changed.emit(hp,max_hp)
    if id=="magnet":
        pickup_radius+=1.3
    _sync_blades()

func grant_shield(charges: int = 1) -> void:
    shield_charges += charges
    AnimaFX.ring(get_parent(),global_position,Color(.65,.72,1),2.2,.4)

func grant_fury(seconds: float = 8.0, bonus: float = 0.30) -> void:
    temporary_damage_bonus=max(temporary_damage_bonus,bonus)
    temporary_damage_time=max(temporary_damage_time,seconds)
    AnimaFX.aura_burst(get_parent(),global_position,Color(1.0,.25,.08),2.4)

func gain_anima(amount: float) -> void:
    anima_charge=clamp(anima_charge+amount,0.0,anima_max)
    anima_changed.emit(anima_charge,anima_max)
    if anima_charge>=anima_max and anima_charge-amount<anima_max:
        AnimaFX.aura_burst(get_parent(),global_position,accent_color,2.8)

func use_anima_burst() -> void:
    if anima_charge<anima_max*.999:
        return
    anima_charge=0.0
    AnimaAudio.play_sfx("ultimate",.86,.98,1.02)
    anima_changed.emit(anima_charge,anima_max)
    iframe=max(iframe,.85)
    camera_shake=max(camera_shake,.58)
    dash_fov_boost=max(dash_fov_boost,3.0)
    _trigger_cast("ultimate",1.35)
    AnimaFX.rune_circle(get_parent(),global_position,accent_color,4.6,.62)
    AnimaFX.aura_burst(get_parent(),global_position,accent_color,5.2)
    match hero_id:
        "sakura":
            AnimaFX.blade_storm(get_parent(),global_position,Color(.50,.96,1.0),8.0)
            for e in get_tree().get_nodes_in_group("enemies"):
                if is_instance_valid(e) and global_position.distance_to(e.global_position)<8.3:
                    e.take_damage(72.0*damage_mult,(e.global_position-global_position).normalized()*5.5,true)
        "kaito":
            AnimaFX.void_bloom(get_parent(),global_position,Color(1.0,.20,.72),6.0)
            var targets=get_tree().get_nodes_in_group("enemies")
            targets.sort_custom(func(a,b): return global_position.distance_to(a.global_position)<global_position.distance_to(b.global_position))
            for i in range(min(12,targets.size())):
                var e=targets[i]
                if is_instance_valid(e):
                    var d=(e.global_position-global_position).normalized()
                    get_tree().current_scene.spawn_player_projectile(global_position+Vector3.UP*1.15,d,62.0*damage_mult,2,Color(1,.20,.72),max(.22,crit_chance),"void")
        "luna":
            grant_shield(2)
            AnimaFX.eclipse(get_parent(),global_position,Color(.55,.34,1.0),9.0)
            for e in get_tree().get_nodes_in_group("enemies"):
                if is_instance_valid(e) and global_position.distance_to(e.global_position)<9.5:
                    e.take_damage(58.0*damage_mult,(e.global_position-global_position).normalized()*3.0,false)
                    e.speed*=.62
        "ren":
            grant_fury(9.0,.58)
            AnimaFX.crimson_cyclone(get_parent(),global_position,Color(1.0,.26,.08),7.0)
            for e in get_tree().get_nodes_in_group("enemies"):
                if is_instance_valid(e) and global_position.distance_to(e.global_position)<7.2:
                    e.take_damage(66.0*damage_mult,(e.global_position-global_position).normalized()*6.0,randf()<max(.32,crit_chance))

func _sync_blades() -> void:
    var need=int(upgrades.get("blade",0))
    var count=0 if need<=0 else 1+int((need-1)/2)
    while blade_nodes.size()<count:
        var bm:=BoxMesh.new(); bm.size=Vector3(.08,.08,1.15)
        var n:=AnimaFX.primitive(bm,Color(.5,.95,1),4.0); weapon_anchor.add_child(n); blade_nodes.append(n)
    while blade_nodes.size()>count:
        blade_nodes.pop_back().queue_free()

func _nearest_enemy(max_range: float=30.0) -> Node3D:
    var best:Node3D; var bd=max_range
    for e in get_tree().get_nodes_in_group("enemies"):
        if not is_instance_valid(e):
            continue
        var d=global_position.distance_to(e.global_position)
        if d<bd:
            bd=d
            best=e
    return best

func _update_weapons(delta: float) -> void:
    blade_angle+=delta*(2.4+upgrades.get("blade",0)*.16)
    blade_trail_clock=max(0.0,blade_trail_clock-delta)
    var bc=max(1,blade_nodes.size())
    for i in range(blade_nodes.size()):
        var a=blade_angle+TAU*float(i)/bc
        var r=1.5+upgrades.get("blade",0)*.07
        var n=blade_nodes[i]
        n.position=Vector3(cos(a)*r,.2,sin(a)*r)
        n.rotation=Vector3(0,-a,PI*.5)
        if blade_trail_clock<=0.0:
            var tangent=Vector3(-sin(a),0,cos(a))
            AnimaFX.blade_orbit_trail(get_parent(),n.global_position,Color(.50,.95,1.0),tangent)
    if blade_nodes.size()>0 and blade_trail_clock<=0.0:
        blade_trail_clock=.055
    if blade_nodes.size()>0:
        for e in get_tree().get_nodes_in_group("enemies"):
            if not is_instance_valid(e):
                continue
            if global_position.distance_to(e.global_position)<2.05:
                var id=e.get_instance_id()
                var t=float(blade_hit_cd.get(id,0.0))-delta
                if t<=0:
                    var hit_dir=(e.global_position-global_position).normalized()
                    e.take_damage((10+upgrades.blade*5)*damage_mult*(1.0+temporary_damage_bonus),hit_dir*2.0,false)
                    AnimaFX.arc_sweep(get_parent(),e.global_position-hit_dir*.35,hit_dir,Color(.50,.95,1.0),1.05,1.25,.045)
                    AnimaFX.steel_impact(get_parent(),e.global_position+Vector3.UP*.72,hit_dir,1.0)
                    t=.34
                blade_hit_cd[id]=t

    for key in weapon_timers.keys():
        weapon_timers[key]=max(0.0,float(weapon_timers[key])-delta)

    if upgrades.shard>0 and weapon_timers.shard<=0:
        var e=_nearest_enemy()
        if e:
            var dir=(e.global_position-global_position).normalized()
            _trigger_attack("shard",1.0)
            AnimaFX.weapon_muzzle(get_parent(),global_position+Vector3.UP*.86+dir*.38,dir,Color(1,.20,.70),1.0)
            get_tree().current_scene.spawn_player_projectile(global_position+Vector3.UP*.86,dir,(13+upgrades.shard*7)*damage_mult*(1.0+temporary_damage_bonus),1+int(upgrades.shard/3),Color(1,.2,.7),crit_chance,"shard")
        weapon_timers.shard=max(.22,(.82-upgrades.shard*.055)*cooldown_mult)

    if upgrades.ring>0 and weapon_timers.ring<=0:
        _trigger_cast("ring",1.0)
        var radius=3.0+upgrades.ring*.45
        AnimaFX.rune_circle(get_parent(),global_position,Color(.62,.35,1),radius,.34)
        AnimaFX.transient_light(get_parent(),global_position+Vector3.UP*.8,Color(.62,.35,1),5.6,radius*1.25,.22)
        AnimaFX.aura_burst(get_parent(),global_position,Color(.62,.35,1),radius*.62)
        for e in get_tree().get_nodes_in_group("enemies"):
            if is_instance_valid(e) and global_position.distance_to(e.global_position)<radius:
                e.take_damage((18+upgrades.ring*8)*damage_mult*(1.0+temporary_damage_bonus),(e.global_position-global_position).normalized()*1.6,false)
        weapon_timers.ring=max(.45,(2.0-upgrades.ring*.12)*cooldown_mult)

    if upgrades.whip>0 and weapon_timers.whip<=0:
        var dir=last_dir
        _trigger_attack("whip",1.15)
        AnimaFX.whip_arc(get_parent(),global_position,dir,Color(1,.33,.12),3.2+upgrades.whip*.25)
        AnimaFX.transient_light(get_parent(),global_position+Vector3.UP*.8+dir*1.5,Color(1,.26,.06),4.8,4.0,.15)
        for e in get_tree().get_nodes_in_group("enemies"):
            if not is_instance_valid(e):
                continue
            var v=e.global_position-global_position; v.y=0
            if v.length()<4.2 and v.length_squared()>.001 and dir.dot(v.normalized())>.15:
                e.take_damage((22+upgrades.whip*9)*damage_mult*(1.0+temporary_damage_bonus),dir*3.0,false)
        weapon_timers.whip=max(.32,(1.15-upgrades.whip*.06)*cooldown_mult)

    if upgrades.owls>0 and weapon_timers.owls<=0:
        _trigger_cast("owls",.9)
        var candidates=get_tree().get_nodes_in_group("enemies")
        candidates.sort_custom(func(a,b): return global_position.distance_to(a.global_position)<global_position.distance_to(b.global_position))
        for i in range(min(1+int(upgrades.owls/2),candidates.size())):
            var e=candidates[i]
            if not is_instance_valid(e):
                continue
            var dir=(e.global_position-global_position).normalized()
            var launch_pos=global_position+Vector3.UP*1.4+Vector3(-dir.z,0,dir.x)*(.18*(i%3-1))
            AnimaFX.owl_launch(get_parent(),launch_pos,dir,Color(.25,1,.68))
            get_tree().current_scene.spawn_player_projectile(launch_pos,dir,(11+upgrades.owls*5)*damage_mult*(1.0+temporary_damage_bonus),1,Color(.25,1,.68),crit_chance,"owl")
        weapon_timers.owls=max(.38,(1.35-upgrades.owls*.07)*cooldown_mult)

    if upgrades.thunder>0 and weapon_timers.thunder<=0:
        _trigger_cast("thunder",1.05)
        AnimaAudio.play_sfx("thunder",.72,.96,1.03)
        var candidates=get_tree().get_nodes_in_group("enemies")
        candidates.sort_custom(func(a,b): return global_position.distance_to(a.global_position)<global_position.distance_to(b.global_position))
        var strikes=min(1+int(upgrades.thunder/3),candidates.size())
        var previous=global_position+Vector3.UP*4.4
        for i in range(strikes):
            var e=candidates[i]
            if not is_instance_valid(e) or global_position.distance_to(e.global_position)>18.0:
                continue
            var target=e.global_position+Vector3.UP*.8
            AnimaFX.thunder_sigil(get_parent(),e.global_position,Color(1,.9,.3),1.15+.12*upgrades.thunder)
            AnimaFX.lightning(get_parent(),previous,target,Color(1,.9,.3))
            e.take_damage((30+upgrades.thunder*14)*damage_mult*(1.0+temporary_damage_bonus),Vector3.ZERO,randf()<crit_chance)
            previous=target
        weapon_timers.thunder=max(.52,(2.3-upgrades.thunder*.12)*cooldown_mult)

func _exit_tree() -> void:
    if is_instance_valid(camera): camera.queue_free()
    if is_instance_valid(contact_shadow): contact_shadow.queue_free()
