class_name AnimaProjectile
extends Area3D

var velocity := Vector3.ZERO
var damage := 10.0
var pierce := 1
var life := 3.0
var owner_team := 0
var crit_chance := 0.08
var hit_ids := {}
var color := Color(0.5,0.9,1.0)
var trail_clock := 0.0
var style := "default"
var flight_time := 0.0
var base_speed := 1.0
var visual_root: Node3D

func setup(dir: Vector3, speed: float, dmg: float, p: int, c: Color, team: int = 0, projectile_style: String = "default") -> void:
    velocity = dir.normalized() * speed
    base_speed = speed
    damage = dmg
    pierce = p
    color = c
    owner_team = team
    style = projectile_style
    collision_layer = 8
    collision_mask = 4 if team == 0 else 2
    monitoring = true
    monitorable = true

    var shape := CollisionShape3D.new()
    var ss := SphereShape3D.new(); ss.radius = 0.30 if style in ["void","owl"] else 0.25
    shape.shape = ss
    add_child(shape)

    visual_root=Node3D.new(); add_child(visual_root)
    if style in ["shard","void"]:
        var crystal:=BoxMesh.new(); crystal.size=Vector3(.14,.14,.76 if style=="shard" else 1.0)
        var body:=AnimaFX.primitive(crystal,c,8.0 if style=="void" else 6.0,.12,.62); visual_root.add_child(body)
        body.rotation.z=PI*.25
        if style=="void":
            var core:=SphereMesh.new(); core.radius=.13; core.height=.26
            var cn:=AnimaFX.primitive(core,Color(1,.72,.94),10.0,.08,.18); visual_root.add_child(cn); cn.scale=Vector3(.65,.65,1.2)
    elif style=="owl":
        var core:=SphereMesh.new(); core.radius=.10; core.height=.20
        var body:=AnimaFX.primitive(core,c,8.0,.16,.12); visual_root.add_child(body)
        for side in [-1.0,1.0]:
            var wing:=BoxMesh.new(); wing.size=Vector3(.32,.035,.18)
            var wn:=AnimaFX.primitive(wing,Color(c.r,c.g,c.b,.78),6.0); visual_root.add_child(wn); wn.position.x=side*.18; wn.rotation.z=side*.24
    else:
        var mesh := SphereMesh.new(); mesh.radius = 0.13; mesh.height = 0.26
        var body := AnimaFX.primitive(mesh, c, 6.0)
        body.scale = Vector3(0.55,0.55,1.8)
        visual_root.add_child(body)

    if style in ["shard","void","owl"]:
        var glow:=OmniLight3D.new(); glow.light_color=c; glow.light_energy=1.65 if style!="void" else 2.6; glow.omni_range=2.2 if style!="void" else 3.4; glow.shadow_enabled=false; visual_root.add_child(glow)

    if dir.length_squared()>.001:
        visual_root.look_at(visual_root.global_position + dir, Vector3.UP)
    area_entered.connect(_on_area)
    body_entered.connect(_on_body)

func _physics_process(delta: float) -> void:
    flight_time += delta
    if style=="owl":
        visual_root.rotation.z=sin(flight_time*22.0)*.18
    elif style=="void":
        visual_root.rotation.z+=delta*7.5
        visual_root.scale=Vector3.ONE*(1.0+sin(flight_time*18.0)*.06)
    elif style=="shard":
        visual_root.rotation.z+=delta*3.8

    global_position += velocity * delta
    trail_clock -= delta
    if trail_clock <= 0.0:
        trail_clock = .024 if style in ["void","shard"] else (.035 if owner_team == 0 else .065)
        AnimaFX.trail_styled(get_parent(),global_position,color,style,velocity.normalized())
    life -= delta
    if life <= 0.0:
        queue_free()

func _hit(body: Node) -> void:
    if not is_instance_valid(body):
        return
    if hit_ids.has(body.get_instance_id()):
        return
    hit_ids[body.get_instance_id()] = true
    if body.has_method("take_damage"):
        var crit := randf() < crit_chance
        body.take_damage(damage * (1.8 if crit else 1.0), velocity.normalized() * (3.2 if style=="void" else 2.4), crit)
        if style=="owl":
            AnimaFX.owl_launch(get_parent(),global_position,velocity.normalized(),color)
        elif style in ["shard","void"]:
            AnimaFX.magic_impact(get_parent(),global_position,color,1.12 if style=="void" else .78)
        else:
            AnimaFX.impact(get_parent(), global_position, color, 0.65)
        pierce -= 1
        if pierce <= 0:
            queue_free()

func _on_area(a: Area3D) -> void: _hit(a)
func _on_body(b: Node3D) -> void: _hit(b)
